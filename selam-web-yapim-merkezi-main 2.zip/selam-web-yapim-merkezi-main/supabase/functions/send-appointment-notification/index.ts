
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AppointmentNotificationRequest {
  appointmentId: string;
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  specialistEmail: string;
  specialistName: string;
  appointmentDate: string;
  appointmentTime: string;
  appointmentType: string;
  notes?: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const {
      appointmentId,
      patientName,
      patientEmail,
      patientPhone,
      specialistEmail,
      specialistName,
      appointmentDate,
      appointmentTime,
      appointmentType,
      notes
    }: AppointmentNotificationRequest = await req.json();

    console.log('📧 Randevu bildirimi gönderiliyor:', {
      appointmentId,
      specialistEmail,
      patientName
    });

    const brevoApiKey = Deno.env.get('BREVO_API_KEY');
    
    if (!brevoApiKey) {
      throw new Error('BREVO_API_KEY bulunamadı');
    }

    // Uzmana gönderilecek e-posta içeriği
    const appointmentTypeText = appointmentType === 'face-to-face' ? 'Yüz Yüze' : 'Online';
    const formattedDate = new Date(appointmentDate).toLocaleDateString('tr-TR');

    const emailContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 10px 10px 0 0; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 24px;">🗓️ Yeni Randevu Talebi</h1>
        </div>
        
        <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px;">
          <h2 style="color: #333; margin-top: 0;">Sayın ${specialistName},</h2>
          <p style="color: #555; font-size: 16px; line-height: 1.6;">
            Size yeni bir randevu talebi geldi. Aşağıda randevu detaylarını bulabilirsiniz:
          </p>
          
          <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea;">
            <h3 style="color: #333; margin-top: 0;">📋 Randevu Detayları</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold; color: #555;">Hasta Adı:</td>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #333;">${patientName}</td>
              </tr>
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold; color: #555;">E-posta:</td>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #333;">${patientEmail}</td>
              </tr>
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold; color: #555;">Telefon:</td>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #333;">${patientPhone}</td>
              </tr>
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold; color: #555;">Tarih:</td>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #333;">${formattedDate}</td>
              </tr>
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold; color: #555;">Saat:</td>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #333;">${appointmentTime}</td>
              </tr>
              <tr>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold; color: #555;">Randevu Türü:</td>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #333;">${appointmentTypeText}</td>
              </tr>
              ${notes ? `
              <tr>
                <td style="padding: 10px 0; font-weight: bold; color: #555;">Notlar:</td>
                <td style="padding: 10px 0; color: #333;">${notes}</td>
              </tr>
              ` : ''}
            </table>
          </div>

          <div style="background: #e3f2fd; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0; color: #1976d2; font-size: 14px;">
              💡 <strong>Bilgi:</strong> Bu randevu talebi henüz onay bekliyor. Doktor panelinizden randevuyu onaylayabilir veya iptal edebilirsiniz.
            </p>
          </div>

          <div style="text-align: center; margin: 30px 0;">
            <a href="https://doktorumol.com.tr/doctor" 
               style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                      color: white; 
                      padding: 12px 30px; 
                      text-decoration: none; 
                      border-radius: 6px; 
                      font-weight: bold;
                      display: inline-block;">
              🩺 Doktor Paneline Git
            </a>
          </div>

          <div style="border-top: 1px solid #ddd; padding-top: 20px; margin-top: 30px; text-align: center;">
            <p style="color: #888; font-size: 12px; margin: 0;">
              Bu e-posta doktorumol.com.tr randevu sistemi tarafından otomatik olarak gönderilmiştir.
            </p>
          </div>
        </div>
      </div>
    `;

    // Brevo API ile e-posta gönder
    const brevoResponse = await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'api-key': brevoApiKey,
      },
      body: JSON.stringify({
        sender: {
          name: 'Doktorum Ol',
          email: 'info@doktorumol.com.tr'
        },
        to: [{
          email: specialistEmail,
          name: specialistName
        }],
        subject: `🗓️ Yeni Randevu Talebi - ${patientName}`,
        htmlContent: emailContent
      })
    });

    if (!brevoResponse.ok) {
      const errorText = await brevoResponse.text();
      console.error('❌ Brevo API hatası:', errorText);
      throw new Error(`Brevo API error: ${brevoResponse.status} - ${errorText}`);
    }

    const result = await brevoResponse.json();
    console.log('✅ Randevu bildirimi başarıyla gönderildi:', result);

    return new Response(
      JSON.stringify({ 
        success: true, 
        messageId: result.messageId,
        message: 'Randevu bildirimi başarıyla gönderildi' 
      }),
      {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
        status: 200,
      }
    );

  } catch (error) {
    console.error('❌ Randevu bildirimi gönderim hatası:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
        status: 500,
      }
    );
  }
});
