
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('Missing environment variables')
      return new Response(
        JSON.stringify({ error: 'Server configuration error' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500,
        },
      )
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    })

    // Get user from request
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'No authorization header' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 401,
        },
      )
    }

    // Verify user has permission
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token)
    
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid token' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 401,
        },
      )
    }

    // Check if user can manage users
    const { data: canManage, error: permError } = await supabaseAdmin
      .rpc('can_manage_users')

    if (permError || !canManage) {
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 403,
        },
      )
    }

    const requestBody = await req.json()
    const { action, userId, userData } = requestBody

    console.log('Secure user management request:', { action, userId, hasUserData: !!userData })

    switch (action) {
      case 'updateUser':
        if (!userId || !userData) {
          return new Response(
            JSON.stringify({ error: 'Missing userId or userData' }),
            {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
              status: 400,
            },
          )
        }

        // Update user profile
        const { error: profileError } = await supabaseAdmin
          .from('user_profiles')
          .update({
            role: userData.role,
            is_approved: userData.is_approved,
            email: userData.email
          })
          .eq('user_id', userId)

        if (profileError) {
          console.error('Profile update error:', profileError)
          return new Response(
            JSON.stringify({ error: 'Failed to update profile' }),
            {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
              status: 400,
            },
          )
        }

        // Update auth if needed
        if (userData.email || userData.password) {
          const updateData: any = {}
          if (userData.email) updateData.email = userData.email
          if (userData.password) updateData.password = userData.password

          const { error: authError } = await supabaseAdmin.auth.admin.updateUserById(
            userId,
            updateData
          )

          if (authError) {
            console.error('Auth update error:', authError)
            return new Response(
              JSON.stringify({ error: 'Profile updated but auth update failed' }),
              {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' },
                status: 207,
              },
            )
          }
        }

        return new Response(
          JSON.stringify({ success: true }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          },
        )

      case 'deleteUser':
        if (!userId) {
          return new Response(
            JSON.stringify({ error: 'Missing userId' }),
            {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
              status: 400,
            },
          )
        }

        // Delete user from auth
        const { error: deleteError } = await supabaseAdmin.auth.admin.deleteUser(userId)

        if (deleteError) {
          console.error('User deletion error:', deleteError)
          return new Response(
            JSON.stringify({ error: 'Failed to delete user' }),
            {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
              status: 400,
            },
          )
        }

        return new Response(
          JSON.stringify({ success: true }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          },
        )

      default:
        return new Response(
          JSON.stringify({ error: 'Invalid action' }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 400,
          },
        )
    }
  } catch (error) {
    console.error('Unexpected error:', error)
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'An unexpected error occurred' 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    )
  }
})
