
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import jsPDF from "https://esm.sh/jspdf@3.0.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface EmailData {
  customerData: {
    name: string;
    surname: string;
    email: string;
    phone: string;
    tcNo: string;
    address: string;
    city: string;
    postalCode?: string;
    companyName?: string;
    taxNo?: string;
    taxOffice?: string;
  };
  packageData: {
    name: string;
    price: number;
    originalPrice: number;
  };
  paymentMethod: string;
  customerType: string;
  orderId: string;
}

// PDF oluşturma fonksiyonları
const generatePreInfoPDF = (customerData: any, packageData: any, paymentMethod: string, customerType: string, clientIP: string) => {
  const pdf = new jsPDF();
  const pageWidth = pdf.internal.pageSize.width;
  const margin = 20;
  let yPosition = 30;
  
  // Header
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('ÖN BİLGİLENDİRME FORMU', pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 10;
  
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  pdf.text('(6502 Sayılı Tüketicinin Korunması Hakkında Kanun Kapsamında)', pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 20;
  
  // Tarih ve IP bilgisi
  const currentDate = new Date().toLocaleDateString('tr-TR');
  pdf.text(`Belge Tarihi: ${currentDate}`, margin, yPosition);
  yPosition += 8;
  pdf.text(`IP Adresi: ${clientIP}`, margin, yPosition);
  yPosition += 15;
  
  // Satıcı bilgileri
  pdf.setFont('helvetica', 'bold');
  pdf.text('SATICI FİRMA BİLGİLERİ', margin, yPosition);
  pdf.setFont('helvetica', 'normal');
  yPosition += 12;
  
  const sellerInfo = [
    'Ünvan: DoktorumOL Dijital Sağlık Hizmetleri',
    'Adres: İstanbul, Türkiye',
    'Telefon: +90 XXX XXX XX XX',
    'E-posta: info@doktorumol.com.tr',
    'Web Sitesi: www.doktorumol.com.tr'
  ];
  
  sellerInfo.forEach((info) => {
    pdf.text(info, margin, yPosition);
    yPosition += 8;
  });
  
  yPosition += 10;
  
  // Müşteri bilgileri
  pdf.setFont('helvetica', 'bold');
  pdf.text('ALICI MÜŞTERİ BİLGİLERİ', margin, yPosition);
  pdf.setFont('helvetica', 'normal');
  yPosition += 12;
  
  const customerInfo = [
    `Ad Soyad: ${customerData.name} ${customerData.surname}`,
    `E-posta Adresi: ${customerData.email}`,
    `Telefon Numarası: ${customerData.phone}`,
    `TC Kimlik No: ${customerData.tcNo}`,
    `Adres: ${customerData.address}, ${customerData.city}`
  ];
  
  if (customerType === 'company' && customerData.companyName) {
    customerInfo.push(`Firma Adı: ${customerData.companyName}`);
    customerInfo.push(`Vergi No: ${customerData.taxNo}`);
    customerInfo.push(`Vergi Dairesi: ${customerData.taxOffice}`);
  }
  
  customerInfo.forEach((info) => {
    pdf.text(info, margin, yPosition);
    yPosition += 8;
  });
  
  yPosition += 10;
  
  // Hizmet bilgileri
  pdf.setFont('helvetica', 'bold');
  pdf.text('HİZMET BİLGİLERİ VE SÖZLEŞME KONUSU', margin, yPosition);
  pdf.setFont('helvetica', 'normal');
  yPosition += 12;
  
  const serviceInfo = [
    `Hizmet Adı: ${packageData.name}`,
    `Aylık Hizmet Bedeli: ${packageData.price.toLocaleString('tr-TR')} TL (KDV Dahil)`,
    `Ödeme Şekli: ${paymentMethod === 'credit_card' ? 'Kredi Kartı ile Aylık Otomatik Tahsilat' : 'Banka Havalesi/EFT ile Aylık Manuel Ödeme'}`,
    'Cayma Hakkı: 14 gün içerisinde herhangi bir gerekçe göstermeksizin cayma hakkınız vardır.'
  ];
  
  serviceInfo.forEach((info) => {
    pdf.text(info, margin, yPosition);
    yPosition += 8;
  });
  
  return pdf;
};

const generateDistanceSalesPDF = (customerData: any, packageData: any, paymentMethod: string, customerType: string, clientIP: string) => {
  const pdf = new jsPDF();
  const pageWidth = pdf.internal.pageSize.width;
  const margin = 20;
  let yPosition = 30;
  
  // Header
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('MESAFELİ SATIŞ SÖZLEŞMESİ', pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 10;
  
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  pdf.text('(6502 Sayılı Tüketicinin Korunması Hakkında Kanun Uyarınca)', pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 20;
  
  // Tarih ve IP bilgisi
  const currentDate = new Date().toLocaleDateString('tr-TR');
  pdf.text(`Sözleşme Tarihi: ${currentDate}`, margin, yPosition);
  yPosition += 8;
  pdf.text(`IP Adresi: ${clientIP}`, margin, yPosition);
  yPosition += 15;
  
  // Taraflar
  pdf.setFont('helvetica', 'bold');
  pdf.text('SÖZLEŞME TARAFLARI', margin, yPosition);
  pdf.setFont('helvetica', 'normal');
  yPosition += 12;
  
  pdf.setFont('helvetica', 'bold');
  pdf.text('SATICI:', margin, yPosition);
  pdf.setFont('helvetica', 'normal');
  yPosition += 10;
  
  const sellerDetails = [
    'Ünvan: DoktorumOL Dijital Sağlık Hizmetleri',
    'Adres: İstanbul, Türkiye',
    'E-posta: info@doktorumol.com.tr'
  ];
  
  sellerDetails.forEach((detail) => {
    pdf.text(detail, margin + 10, yPosition);
    yPosition += 7;
  });
  
  yPosition += 10;
  
  pdf.setFont('helvetica', 'bold');
  pdf.text('ALICI:', margin, yPosition);
  pdf.setFont('helvetica', 'normal');
  yPosition += 10;
  
  const buyerDetails = [
    `Ad Soyad: ${customerData.name} ${customerData.surname}`,
    `E-posta: ${customerData.email}`,
    `Telefon: ${customerData.phone}`,
    `Adres: ${customerData.address}, ${customerData.city}`
  ];
  
  buyerDetails.forEach((detail) => {
    pdf.text(detail, margin + 10, yPosition);
    yPosition += 7;
  });
  
  yPosition += 15;
  
  // Sözleşme konusu
  pdf.setFont('helvetica', 'bold');
  pdf.text('SÖZLEŞME KONUSU VE DETAYLARI', margin, yPosition);
  pdf.setFont('helvetica', 'normal');
  yPosition += 12;
  
  const contractDetails = [
    `Hizmet Adı: ${packageData.name}`,
    `Aylık Ücret: ${packageData.price.toLocaleString('tr-TR')} TL`,
    `Ödeme Yöntemi: ${paymentMethod === 'credit_card' ? 'Kredi Kartı' : 'Banka Havalesi'}`,
    'Hizmet Süresi: 24 Ay',
    'Cayma Hakkı: 14 gün'
  ];
  
  contractDetails.forEach((detail) => {
    pdf.text(detail, margin, yPosition);
    yPosition += 8;
  });
  
  return pdf;
};

const createOrderCompletionEmailTemplate = (customerData: any, packageData: any, paymentMethod: string, customerType: string) => {
  const orderDate = new Date().toLocaleDateString('tr-TR');
  const orderTime = new Date().toLocaleTimeString('tr-TR');
  
  return `
    <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 650px; margin: 0 auto; background-color: #f8fafc; padding: 20px;">
      <!-- Header -->
      <div style="background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); color: white; padding: 30px 20px; border-radius: 12px 12px 0 0; text-align: center;">
        <h1 style="margin: 0; font-size: 28px; font-weight: bold;">DoktorumOL</h1>
        <p style="margin: 10px 0 0 0; font-size: 16px; opacity: 0.9;">Profesyonel Sağlık Platformu</p>
      </div>

      <!-- Success Message -->
      <div style="background-color: white; padding: 30px; border-left: 4px solid #10b981;">
        <div style="display: flex; align-items: center; margin-bottom: 20px;">
          <div style="width: 50px; height: 50px; background-color: #10b981; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px;">
            <span style="color: white; font-size: 24px;">✓</span>
          </div>
          <div>
            <h2 style="margin: 0; color: #1f2937; font-size: 24px;">Siparişiniz Tamamlandı!</h2>
            <p style="margin: 5px 0 0 0; color: #6b7280;">Teşekkür ederiz, ${customerData.name} ${customerData.surname}</p>
          </div>
        </div>
      </div>

      <!-- Order Details -->
      <div style="background-color: white; padding: 25px; margin-top: 2px;">
        <h3 style="color: #1f2937; margin-top: 0; margin-bottom: 20px; font-size: 20px; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">
          📋 Sipariş Detayları
        </h3>
        
        <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-weight: 500;">Sipariş Tarihi:</td>
              <td style="padding: 8px 0; color: #1f2937; font-weight: 600;">${orderDate} ${orderTime}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-weight: 500;">Paket:</td>
              <td style="padding: 8px 0; color: #1f2937; font-weight: 600;">${packageData.name}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-weight: 500;">Aylık Ücret:</td>
              <td style="padding: 8px 0; color: #1f2937; font-weight: 600;">${packageData.price.toLocaleString('tr-TR')} ₺</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-weight: 500;">Ödeme Yöntemi:</td>
              <td style="padding: 8px 0; color: #1f2937; font-weight: 600;">${paymentMethod === 'credit_card' ? 'Kredi Kartı' : 'Banka Havalesi'}</td>
            </tr>
          </table>
        </div>
      </div>

      <!-- Customer Information -->
      <div style="background-color: white; padding: 25px; margin-top: 2px;">
        <h3 style="color: #1f2937; margin-top: 0; margin-bottom: 20px; font-size: 20px; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">
          👤 Fatura Bilgileri
        </h3>
        
        <div style="background-color: #f0f9ff; padding: 20px; border-radius: 8px; border-left: 4px solid #3b82f6;">
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 6px 0; color: #1e40af; font-weight: 500; width: 140px;">Ad Soyad:</td>
              <td style="padding: 6px 0; color: #1e3a8a; font-weight: 600;">${customerData.name} ${customerData.surname}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #1e40af; font-weight: 500;">E-posta:</td>
              <td style="padding: 6px 0; color: #1e3a8a;">${customerData.email}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #1e40af; font-weight: 500;">Telefon:</td>
              <td style="padding: 6px 0; color: #1e3a8a;">${customerData.phone}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #1e40af; font-weight: 500;">Adres:</td>
              <td style="padding: 6px 0; color: #1e3a8a;">${customerData.address}, ${customerData.city}</td>
            </tr>
            ${customerType === 'company' && customerData.companyName ? `
            <tr>
              <td style="padding: 6px 0; color: #1e40af; font-weight: 500;">Firma:</td>
              <td style="padding: 6px 0; color: #1e3a8a;">${customerData.companyName}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #1e40af; font-weight: 500;">Vergi No:</td>
              <td style="padding: 6px 0; color: #1e3a8a;">${customerData.taxNo}</td>
            </tr>
            ` : ''}
          </table>
        </div>
      </div>

      <!-- Attachments Info -->
      <div style="background-color: white; padding: 25px; margin-top: 2px;">
        <h3 style="color: #1f2937; margin-top: 0; margin-bottom: 20px; font-size: 20px; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">
          📎 Ekteki Belgeler
        </h3>
        
        <div style="background-color: #fef3c7; padding: 20px; border-radius: 8px; border-left: 4px solid #f59e0b;">
          <p style="color: #92400e; margin: 0 0 15px 0; font-weight: 500;">
            Bu e-postaya aşağıdaki belgeler eklenmiştir:
          </p>
          <ul style="color: #92400e; margin: 0; padding-left: 20px; line-height: 1.8;">
            <li><strong>Ön Bilgilendirme Formu</strong> - Kişiselleştirilmiş belgeniz</li>
            <li><strong>Mesafeli Satış Sözleşmesi</strong> - Hizmet koşullarınız</li>
          </ul>
        </div>
      </div>

      <!-- Footer -->
      <div style="background-color: #1f2937; color: white; padding: 25px; border-radius: 0 0 12px 12px; text-align: center; margin-top: 2px;">
        <p style="margin: 0 0 10px 0; font-size: 14px;">
          Sorularınız için: <a href="mailto:info@doktorumol.com.tr" style="color: #60a5fa;">info@doktorumol.com.tr</a>
        </p>
        <p style="margin: 0; font-size: 12px; opacity: 0.7;">
          © ${new Date().getFullYear()} DoktorumOL - Tüm hakları saklıdır.
        </p>
      </div>
    </div>
  `;
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const emailData: EmailData = await req.json();
    
    console.log('📧 Sipariş tamamlama e-postası hazırlanıyor:', emailData.customerData.email);
    
    // Create Supabase client
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Generate PDFs
    const clientIP = '127.0.0.1'; // In production, get from request headers
    const preInfoPDF = generatePreInfoPDF(emailData.customerData, emailData.packageData, emailData.paymentMethod, emailData.customerType, clientIP);
    const distanceSalesPDF = generateDistanceSalesPDF(emailData.customerData, emailData.packageData, emailData.paymentMethod, emailData.customerType, clientIP);
    
    // Convert PDFs to base64
    const preInfoPDFBase64 = preInfoPDF.output('datauristring').split(',')[1];
    const distanceSalesPDFBase64 = distanceSalesPDF.output('datauristring').split(',')[1];
    
    // Create file names
    const currentDate = new Date().toLocaleDateString('tr-TR').replace(/\./g, '-');
    const preInfoFileName = `${emailData.customerData.name}_${emailData.customerData.surname}_OnBilgilendirme_${currentDate}.pdf`;
    const distanceSalesFileName = `${emailData.customerData.name}_${emailData.customerData.surname}_MesafeliSatis_${currentDate}.pdf`;
    
    // Get Brevo API key
    const brevoApiKey = Deno.env.get("BREVO_API_KEY");
    if (!brevoApiKey) {
      throw new Error("BREVO_API_KEY is not set");
    }

    // Prepare email content
    const emailTemplate = createOrderCompletionEmailTemplate(emailData.customerData, emailData.packageData, emailData.paymentMethod, emailData.customerType);
    
    // Send email with Brevo
    const brevoData = {
      sender: {
        name: "DoktorumOL",
        email: "noreply@doktorumol.com.tr"
      },
      to: [{
        email: emailData.customerData.email,
        name: `${emailData.customerData.name} ${emailData.customerData.surname}`
      }],
      subject: 'DoktorumOL - Siparişiniz Tamamlandı - Sözleşme Belgeleri',
      htmlContent: emailTemplate,
      attachment: [
        {
          name: preInfoFileName,
          content: preInfoPDFBase64
        },
        {
          name: distanceSalesFileName,
          content: distanceSalesPDFBase64
        }
      ]
    };

    console.log('📧 Brevo API ile e-posta gönderiliyor...');

    const brevoResponse = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "api-key": brevoApiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(brevoData),
    });

    if (!brevoResponse.ok) {
      const errorText = await brevoResponse.text();
      console.error("❌ Brevo API hatası:", brevoResponse.status, errorText);
      throw new Error(`Brevo API error: ${brevoResponse.status}`);
    }

    const result = await brevoResponse.json();
    console.log("✅ Sipariş tamamlama e-postası gönderildi:", result);

    // Update order to mark contract emails as sent
    const { error: updateError } = await supabase
      .from('orders')
      .update({ contract_emails_sent: true })
      .eq('id', emailData.orderId);

    if (updateError) {
      console.error('Error updating order:', updateError);
    }

    return new Response(JSON.stringify({
      success: true,
      message: 'Sipariş tamamlama e-postası başarıyla gönderildi',
      messageId: result.messageId
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    console.error('❌ Sipariş tamamlama e-posta hatası:', error);
    return new Response(JSON.stringify({ 
      success: false,
      error: error.message 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
