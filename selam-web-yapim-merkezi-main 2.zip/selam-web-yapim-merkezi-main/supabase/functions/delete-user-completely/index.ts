
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Create admin client
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    const { userId } = await req.json()

    if (!userId) {
      throw new Error('User ID is required')
    }

    console.log('Deleting user completely:', userId)

    // First, clean up related data
    console.log('Cleaning up related data...')

    // Delete specialist profile if exists
    const { error: specialistError } = await supabaseAdmin
      .from('specialists')
      .delete()
      .eq('user_id', userId)

    if (specialistError) {
      console.warn('Warning deleting specialist data:', specialistError)
    }

    // Delete blog posts
    const { error: blogError } = await supabaseAdmin
      .from('blog_posts')
      .delete()
      .eq('author_id', userId)

    if (blogError) {
      console.warn('Warning deleting blog posts:', blogError)
    }

    // Clean up orders references
    const { error: ordersError } = await supabaseAdmin
      .from('orders')
      .update({ approved_by: null })
      .eq('approved_by', userId)

    if (ordersError) {
      console.warn('Warning cleaning orders references:', ordersError)
    }

    // Delete user profile
    console.log('Deleting user profile...')
    const { error: profileError } = await supabaseAdmin
      .from('user_profiles')
      .delete()
      .eq('user_id', userId)

    if (profileError) {
      console.error('Error deleting user profile:', profileError)
      throw new Error('Failed to delete user profile: ' + profileError.message)
    }

    // Delete from auth
    console.log('Deleting from auth system...')
    const { error: authError } = await supabaseAdmin.auth.admin.deleteUser(userId)

    if (authError) {
      console.error('Error deleting auth user:', authError)
      throw new Error('Failed to delete auth user: ' + authError.message)
    }

    console.log('User deleted successfully')

    return new Response(
      JSON.stringify({ success: true, message: 'User deleted completely' }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    console.error('Error deleting user:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    )
  }
})
