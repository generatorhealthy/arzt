
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { phone, message } = await req.json();
    
    console.log('SMS gönderim isteği:', { phone, message });

    // IP adresini logla
    const clientIP = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';
    console.log('İstek IP adresi:', clientIP);

    const apiKey = Deno.env.get('VERIMOR_API_KEY');

    if (!apiKey) {
      console.error('Verimor API Key eksik');
      throw new Error('Verimor API Key eksik');
    }

    console.log('Verimor API Key mevcut, Key başlangıcı:', apiKey.substring(0, 8) + '...');

    // Telefon numarasını 12 haneli Verimor formatına çevir (908xxxxxxxxx)
    let formattedPhone = phone.replace(/\s+/g, '').replace(/[^\d]/g, ''); // Sadece rakamları al
    
    if (formattedPhone.startsWith('0')) {
      formattedPhone = '90' + formattedPhone.substring(1); // 0 yerine 90 ekle
    } else if (!formattedPhone.startsWith('90')) {
      formattedPhone = '90' + formattedPhone; // Başına 90 ekle
    }

    // 12 haneli olup olmadığını kontrol et
    if (formattedPhone.length !== 12) {
      throw new Error(`Geçersiz telefon numarası formatı: ${formattedPhone}. 12 haneli olmalı (908xxxxxxxxx)`);
    }

    console.log('Formatlanmış telefon (12 haneli):', formattedPhone);

    // Verimor İş Ortağı API v2 kullanarak SMS gönder - API Key ile authorization
    const apiUrl = 'https://sms.verimor.com.tr/v2/send.json';
    
    const apiPayload = {
      username: '902167060611', // Kayıtlı telefon numaranız
      password: apiKey, // API Key'i password olarak kullan
      source_addr: '02167060611',
      dest: formattedPhone,
      msg: message,
      datacoding: '0',
      valid_for: '48:00'
    };

    console.log('Verimor API payload:', { ...apiPayload, password: '***' });

    const verimorResponse = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify(apiPayload)
    });

    console.log('Verimor API yanıt status:', verimorResponse.status);

    const responseText = await verimorResponse.text();
    console.log('Verimor API yanıt metni:', responseText);

    if (!verimorResponse.ok) {
      console.error('Verimor API hatası:', responseText);
      
      // Yaygın hata kodlarını kontrol et
      if (responseText.includes('INSUFFICIENT_CREDITS') || responseText.includes('Yetersiz kredi')) {
        throw new Error('Yetersiz kredi - Verimor hesabınızda yeterli SMS kredisi yok');
      } else if (responseText.includes('INVALID_CREDENTIALS') || responseText.includes('Geçersiz') || responseText.includes('Authentication')) {
        throw new Error(`Geçersiz kimlik bilgileri - Verimor panelindeki İş Ortağı API bölümünden doğru kullanıcı adı ve API Key'i kontrol edin. Mevcut username: 902167060611`);
      } else if (responseText.includes('UNAUTHORIZED_IP') || responseText.includes('IP')) {
        throw new Error(`Yetkisiz IP adresi - Sunucu IP adresi (${clientIP}) Verimor panelinde tanımlanmamış. Verimor panelinde IP kısıtlamalarını kaldırın veya bu IP'yi ekleyin.`);
      } else if (responseText.includes('INVALID_SOURCE')) {
        throw new Error('Geçersiz başlık - 02167060611 başlığı hesabınızda tanımlı değil');
      } else if (responseText.includes('INVALID_DEST')) {
        throw new Error('Geçersiz hedef numara formatı');
      }
      
      throw new Error(`Verimor API Hatası (${verimorResponse.status}): ${responseText}`);
    }

    // Başarılı yanıt kontrolü
    let responseData;
    try {
      responseData = JSON.parse(responseText);
    } catch (e) {
      console.log('Yanıt JSON değil, text olarak işleniyor:', responseText);
      responseData = { message_id: responseText.trim() };
    }

    let campaignId = 'unknown';
    if (responseData && responseData.message_id) {
      campaignId = responseData.message_id;
    } else if (typeof responseData === 'string' && /^\d+$/.test(responseData.trim())) {
      campaignId = responseData.trim();
    } else if (responseText && /^\d+$/.test(responseText.trim())) {
      campaignId = responseText.trim();
    }

    console.log('SMS başarıyla gönderildi, Kampanya ID:', campaignId);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'SMS başarıyla gönderildi',
        campaignId: campaignId,
        serverIP: clientIP,
        apiResponse: responseData
      }),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        } 
      }
    );

  } catch (error) {
    console.error('SMS gönderim hatası:', error);
    console.error('Hata detayı:', error.message);
    console.error('Hata stack:', error.stack);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'SMS gönderiminde hata oluştu',
        details: error.stack 
      }),
      { 
        status: 500,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        } 
      }
    );
  }
})
