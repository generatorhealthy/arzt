
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TestResultEmailRequest {
  testResultId: string;
  specialistEmail: string;
  patientName: string;
  patientPhone: string;
  testTitle: string;
  answers: any;
  results: any;
}

const handler = async (req: Request): Promise<Response> => {
  console.log('Test results email function called');

  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { testResultId, specialistEmail, patientName, patientPhone, testTitle, answers, results }: TestResultEmailRequest = await req.json();

    console.log('Sending test results email to:', specialistEmail);

    // E-posta içeriği oluştur
    const emailContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #2563eb; text-align: center;">Test Sonucu</h2>
        
        <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #1e40af; margin-bottom: 10px;">Test Bilgileri</h3>
          <p><strong>Test Adı:</strong> ${testTitle}</p>
          <p><strong>Hasta:</strong> ${patientName}</p>
          <p><strong>Telefon:</strong> ${patientPhone}</p>
          <p><strong>Tarih:</strong> ${new Date().toLocaleDateString('tr-TR')}</p>
        </div>

        <div style="background-color: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #92400e; margin-bottom: 10px;">Hasta Cevapları</h3>
          <pre style="white-space: pre-wrap; font-family: Arial, sans-serif; font-size: 14px;">
${JSON.stringify(answers, null, 2)}
          </pre>
        </div>

        ${results && Object.keys(results).length > 0 ? `
        <div style="background-color: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #1e40af; margin-bottom: 10px;">Test Sonuçları</h3>
          <pre style="white-space: pre-wrap; font-family: Arial, sans-serif; font-size: 14px;">
${JSON.stringify(results, null, 2)}
          </pre>
        </div>
        ` : ''}

        <div style="text-align: center; margin-top: 30px; padding: 20px; background-color: #f1f5f9; border-radius: 8px;">
          <p style="color: #64748b; margin: 0;">Bu e-posta test@doktorumol.com.tr tarafından otomatik olarak gönderilmiştir.</p>
        </div>
      </div>
    `;

    // Burada gerçek e-posta gönderimi yapılacak
    // Şu an için konsola yazdırıyoruz
    console.log('📧 Test sonucu e-postası gönderiliyor:', {
      to: specialistEmail,
      from: 'test@doktorumol.com.tr',
      subject: `Test Sonucu: ${testTitle} - ${patientName}`,
      content: emailContent
    });

    // E-posta gönderim simülasyonu
    // Gerçek implementasyon için Resend, SendGrid vb. kullanılabilir
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Test sonucu e-postası başarıyla gönderildi.' 
      }),
      {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );

  } catch (error: any) {
    console.error('Error in send-test-results-email function:', error);
    
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false 
      }),
      {
        status: 500,
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders 
        },
      }
    );
  }
};

serve(handler);
