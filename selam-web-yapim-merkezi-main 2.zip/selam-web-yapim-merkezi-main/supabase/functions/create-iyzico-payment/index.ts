
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { packageType, customerData, subscriptionReferenceCode } = await req.json();
    
    const apiKey = Deno.env.get("IYZICO_API_KEY");
    const secretKey = Deno.env.get("IYZICO_SECRET_KEY");
    
    if (!apiKey || !secretKey) {
      throw new Error("İyzico API anahtarları yapılandırılmamış");
    }

    // Callback URL'yi doktorumol.com.tr olarak ayarla
    const callbackUrl = "https://doktorumol.com.tr/odeme-basarili";
    
    console.log("Callback URL:", callbackUrl);

    // İyzico abonelik checkout form verilerini hazırla
    const checkoutFormData = {
      locale: "tr",
      conversationId: `order_${Date.now()}`,
      price: "1.00",
      paidPrice: "1.00",
      currency: "TRY",
      basketId: `basket_${Date.now()}`,
      paymentGroup: "SUBSCRIPTION",
      subscriptionInitialStatus: "ACTIVE",
      subscriptionReferenceCode,
      callbackUrl,
      buyer: {
        id: customerData.email,
        name: customerData.name,
        surname: customerData.surname,
        gsmNumber: customerData.phone || "+905300000000",
        email: customerData.email,
        identityNumber: customerData.tcNo || "11111111111",
        registrationAddress: customerData.address || "İstanbul",
        city: customerData.city || "İstanbul",
        country: "Turkey",
        ip: "127.0.0.1"
      },
      shippingAddress: {
        contactName: `${customerData.name} ${customerData.surname}`,
        city: customerData.city || "İstanbul",
        country: "Turkey",
        address: customerData.address || "İstanbul"
      },
      billingAddress: {
        contactName: `${customerData.name} ${customerData.surname}`,
        city: customerData.city || "İstanbul",
        country: "Turkey",
        address: customerData.address || "İstanbul"
      },
      basketItems: [
        {
          id: packageType,
          name: `${packageType} Paketi`,
          category1: "Abonelik",
          itemType: "VIRTUAL",
          price: "1.00"
        }
      ]
    };

    // Random string oluştur
    const randomString = Math.random().toString(36).substring(2, 15);
    
    // Authorization string oluştur
    const authString = `apikey:${apiKey}&conversationId:${checkoutFormData.conversationId}&locale:${checkoutFormData.locale}&price:${checkoutFormData.price}&random:${randomString}`;
    
    console.log("Auth string:", authString);

    // HMAC SHA1 hash oluştur
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      encoder.encode(secretKey),
      { name: "HMAC", hash: "SHA-1" },
      false,
      ["sign"]
    );
    const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(authString));
    const hashArray = Array.from(new Uint8Array(signature));
    const hashBase64 = btoa(hashArray.map(b => String.fromCharCode(b)).join(''));

    console.log("İyzico API'sine istek gönderiliyor...");

    // Production URL kullan
    const iyzipayUrl = "https://api.iyzipay.com/v2/checkout-form/initialize";

    // İyzico'ya istek gönder
    const response = await fetch(iyzipayUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `IYZWS ${apiKey}:${hashBase64}`,
        "x-iyzi-rnd": randomString
      },
      body: JSON.stringify(checkoutFormData)
    });

    const responseText = await response.text();
    console.log("İyzico yanıtı:", responseText);

    let result;
    try {
      result = JSON.parse(responseText);
    } catch (parseError) {
      console.error("İyzico yanıtı parse edilemedi:", parseError);
      throw new Error("İyzico'dan geçersiz yanıt");
    }
    
    if (result.status === "success") {
      // Siparişi veritabanına kaydet
      const supabase = createClient(
        Deno.env.get("SUPABASE_URL") ?? "",
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
      );

      await supabase.from("orders").insert({
        customer_name: `${customerData.name} ${customerData.surname}`,
        customer_email: customerData.email,
        customer_phone: customerData.phone,
        customer_tc_no: customerData.tcNo,
        customer_address: customerData.address,
        customer_city: customerData.city,
        customer_type: customerData.customerType,
        company_name: customerData.companyName,
        company_tax_no: customerData.taxNo,
        company_tax_office: customerData.taxOffice,
        package_name: `${packageType} Paketi`,
        package_type: packageType,
        amount: 1, // Abonelik tutarı İyzico tarafından yönetilecek
        payment_method: "credit_card",
        status: "pending",
        payment_transaction_id: result.token,
        is_first_order: true,
        subscription_month: 1
      });

      return new Response(JSON.stringify({ 
        success: true, 
        checkoutFormContent: result.checkoutFormContent,
        token: result.token,
        paymentPageUrl: result.paymentPageUrl
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200
      });
    } else {
      console.error("İyzico hatası:", result);
      throw new Error(result.errorMessage || "İyzico ödeme başlatılamadı");
    }

  } catch (error) {
    console.error("İyzico ödeme hatası:", error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500
    });
  }
});
