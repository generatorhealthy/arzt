-- Update RLS policies for blog_posts to allow admins to create blog posts
-- Drop existing policies that might be conflicting
DROP POLICY IF EXISTS "Doctors can create blog posts" ON public.blog_posts;

-- Create a new policy that allows both specialists and admins to create blog posts
CREATE POLICY "Specialists and admins can create blog posts" 
ON public.blog_posts 
FOR INSERT 
WITH CHECK (
  (author_id = auth.uid()) AND 
  (
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role = 'specialist'::user_role
    ) OR
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role = 'admin'::user_role
    )
  )
);