
-- Önce mevcut politikayı kontrol edelim ve varsa silelim
DROP POLICY IF EXISTS "Anyone can create appointments" ON public.appointments;

-- Yeni politikayı oluşturalım
CREATE POLICY "Anyone can create appointments" 
  ON public.appointments 
  FOR INSERT 
  WITH CHECK (true);

-- Politikanın aktif olduğunu doğrulayalım
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'appointments';
