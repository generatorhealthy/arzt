
-- Fix the security issue in update_packages_updated_at function
CREATE OR REPLACE FUNCTION public.update_packages_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
    -- Set an explicit, empty search path to prevent schema resolution surprises
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;
