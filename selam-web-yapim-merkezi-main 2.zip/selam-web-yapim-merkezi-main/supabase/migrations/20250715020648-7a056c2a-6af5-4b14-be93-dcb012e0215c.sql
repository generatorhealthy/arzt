
-- Her test için 10'ar adet soru ekleme
-- Önce mevcut test sorularını temizleyelim (eğer varsa)
DELETE FROM test_questions;

-- Fobi Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Yüksek yerlerden korkar mısınız?', 'multiple_choice', '["Hiç korkmam", "Az korkarım", "Orta düzeyde korkarım", "Çok korkarım", "Panik yaşarım"]'::jsonb, 1, true
FROM tests WHERE title = 'Fobi Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kapalı alanlarda rahatsızlık hisseder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 2, true
FROM tests WHERE title = 'Fobi Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Böceklerden korkar mısınız?', 'multiple_choice', '["Hiç korkmam", "Az korkarım", "Orta düzeyde korkarım", "Çok korkarım", "Panik yaşarım"]'::jsonb, 3, true
FROM tests WHERE title = 'Fobi Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sosyal ortamlarda konuşmaktan kaçınır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 4, true
FROM tests WHERE title = 'Fobi Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kan görmeye dayanabilir misiniz?', 'multiple_choice', '["Hiç sorun yok", "Biraz rahatsız olurum", "Orta düzeyde rahatsız olurum", "Çok rahatsız olurum", "Bayılırım"]'::jsonb, 5, true
FROM tests WHERE title = 'Fobi Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Uçak yolculuğu yapabilir misiniz?', 'multiple_choice', '["Rahatça yaparım", "Biraz gergin olurum", "Çok gergin olurum", "Sadece mecburen", "Hiç yapamam"]'::jsonb, 6, true
FROM tests WHERE title = 'Fobi Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Hayvanlardan korkar mısınız?', 'multiple_choice', '["Hiç korkmam", "Bazılarından korkarım", "Çoğundan korkarım", "Hepsinden korkarım", "Panik yaşarım"]'::jsonb, 7, true
FROM tests WHERE title = 'Fobi Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İğne görünce ne hissedersiniz?', 'multiple_choice', '["Normal karşılarım", "Biraz gerilirim", "Çok gerilirim", "Kaçmak isterim", "Bayılırım"]'::jsonb, 8, true
FROM tests WHERE title = 'Fobi Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Karanlıkta kalmayı nasıl bulursunuz?', 'multiple_choice', '["Hiç sorun değil", "Biraz rahatsız olurum", "Çok rahatsız olurum", "Korkuya kapılırım", "Panik yaşarım"]'::jsonb, 9, true
FROM tests WHERE title = 'Fobi Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Suya girmeyi sever misiniz?', 'multiple_choice', '["Çok severim", "Severim", "Kararsızım", "Sevmem", "Hiç giremem"]'::jsonb, 10, true
FROM tests WHERE title = 'Fobi Testi';

-- Dikkat Dağınıklığı Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Bir işe odaklanmakta zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 1, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Detayları gözden kaçırır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 2, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Uzun süreli görevlerde motivasyonunuzu kaybeder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 3, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Organize olmakta zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 4, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Eşyalarınızı kaybeder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 5, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kolayca dikkati dağılır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 6, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Randevularınızı unutur musunuz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 7, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sürekli hareket halinde misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 8, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sabırsızlık yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 9, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İşleri yarım bırakır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 10, true
FROM tests WHERE title = 'Dikkat Dağınıklığı (Eksikliği) Testi';

-- Obsesif Kompulsif Bozukluk Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Ellerinizi sık sık yıkar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 1, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kapıları kontrol etme ihtiyacı hisseder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 2, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Düzen ve simetriye önem verir misiniz?', 'multiple_choice', '["Hiç önemli değil", "Az önemli", "Orta düzeyde", "Çok önemli", "Takıntı düzeyinde"]'::jsonb, 3, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İstenmeyen düşünceler yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 4, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sayma kompulsiyonu yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 5, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Temizlik konusunda aşırı titiz misiniz?', 'multiple_choice', '["Hiç titiz değilim", "Az titizim", "Orta düzeyde", "Çok titizim", "Takıntı düzeyinde"]'::jsonb, 6, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Aynı şeyleri tekrar tekrar kontrol eder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 7, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Eşyaları atmakta zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 8, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Belirlediğiniz rutinlere sıkı sıkıya bağlı mısınız?', 'multiple_choice', '["Hiç bağlı değilim", "Az bağlıyım", "Orta düzeyde", "Çok bağlıyım", "Değiştiremem"]'::jsonb, 9, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Mükemmeliyetçi eğilimleriniz var mı?', 'multiple_choice', '["Hiç yok", "Az var", "Orta düzeyde", "Çok var", "Takıntı düzeyinde"]'::jsonb, 10, true
FROM tests WHERE title = 'Obsesif Kompulsif Bozukluk Testi';

-- Borderline Kişilik Bozukluğu Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İlişkilerinizde aşırı yakınlık ve uzaklık yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 1, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Terk edilme korkusu yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 2, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kendiniz hakkındaki görüşünüz sık değişir mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 3, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Duygusal patlamalar yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 4, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İmpulsif davranışlar sergiler misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 5, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kendinize zarar verme düşünceleriniz olur mu?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 6, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Boşluk hissi yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 7, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Öfke kontrolünde zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 8, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Stres altında paranoid düşünceler yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 9, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İlişkilerinizde idealizasyon ve değersizleştirme yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 10, true
FROM tests WHERE title = 'Borderline (Sınırda) Kişilik Bozukluğu Testi';

-- Aleksitimi Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Duygularınızı tanımlamakta zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 1, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Başkalarının duygularını anlayabilir misiniz?', 'multiple_choice', '["Çok iyi", "İyi", "Orta", "Zor", "Hiç anlayamam"]'::jsonb, 2, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Duygularınızı ifade etmekte zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 3, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Bedensel duyumlarınızı fark eder misiniz?', 'multiple_choice', '["Her zaman", "Sık sık", "Bazen", "Nadiren", "Hiçbir zaman"]'::jsonb, 4, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Hayal kurma yeteneğiniz nasıl?', 'multiple_choice', '["Çok güçlü", "Güçlü", "Orta", "Zayıf", "Çok zayıf"]'::jsonb, 5, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Duygusal filmlerden etkilenir misiniz?', 'multiple_choice', '["Çok etkilenirim", "Etkilenirim", "Orta düzeyde", "Az etkilenirim", "Hiç etkilenmem"]'::jsonb, 6, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Rüyalarınızı hatırlar mısınız?', 'multiple_choice', '["Her zaman", "Sık sık", "Bazen", "Nadiren", "Hiçbir zaman"]'::jsonb, 7, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sanat eserlerinden duygusal etkilenim yaşar mısınız?', 'multiple_choice', '["Çok yaşarım", "Yaşarım", "Orta düzeyde", "Az yaşarım", "Hiç yaşamam"]'::jsonb, 8, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İç dünyaya odaklanır mısınız?', 'multiple_choice', '["Her zaman", "Sık sık", "Bazen", "Nadiren", "Hiçbir zaman"]'::jsonb, 9, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Duygusal yakınlık kurmakta zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 10, true
FROM tests WHERE title = 'Aleksitimi (Duygu Körlüğü) Testi';

-- Anksiyete Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Endişe duygusu yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 1, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kalp çarpıntısı yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 2, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Nefes alma güçlüğü yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 3, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Gerginlik hissi yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 4, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Uyku sorunu yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her gece"]'::jsonb, 5, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kas gerginliği yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 6, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Konsantrasyon güçlüğü yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 7, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Yorgunluk hissi yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 8, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İrritabilite (sinirlilik) yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 9, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sosyal kaçınma davranışı sergiler misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 10, true
FROM tests WHERE title = 'Anksiyete (Kaygı) Testi';

-- Depresyon Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Üzüntü hissi yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 1, true
FROM tests WHERE title = 'Depresyon Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Aktivitelere karşı ilgi kaybı yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 2, true
FROM tests WHERE title = 'Depresyon Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Enerji eksikliği hisseder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 3, true
FROM tests WHERE title = 'Depresyon Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Uyku düzensizlikleri yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her gece"]'::jsonb, 4, true
FROM tests WHERE title = 'Depresyon Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İştah değişiklikleri yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 5, true
FROM tests WHERE title = 'Depresyon Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Değersizlik hissi yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 6, true
FROM tests WHERE title = 'Depresyon Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Karar vermekte zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 7, true
FROM tests WHERE title = 'Depresyon Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Hareketlerde yavaşlama yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 8, true
FROM tests WHERE title = 'Depresyon Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Suçluluk hissi yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 9, true
FROM tests WHERE title = 'Depresyon Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Gelecek hakkında olumsuz düşünceleriniz var mı?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 10, true
FROM tests WHERE title = 'Depresyon Testi';

-- Travmatik Yaş Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Geçmişte travmatik bir olay yaşadınız mı?', 'multiple_choice', '["Hayır", "Küçük travmalar", "Orta düzey travma", "Ciddi travma", "Çoklu travmalar"]'::jsonb, 1, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kötü anılarınız sizi rahatsız eder mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 2, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kabus görür müsünüz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her gece"]'::jsonb, 3, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Ani panik atakları yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 4, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Belirli yerlerden kaçınır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 5, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Duygusal uyuşukluk yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 6, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Aşırı tetikte olma hali yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 7, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Konsantrasyon güçlüğü yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 8, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İrritabilite (aşırı sinirlilik) yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 9, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Travmatik olayı hatırlatan şeylerden kaçınır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 10, true
FROM tests WHERE title = 'Travmatik Yaş Testi';

-- Travma Sonrası Stres Bozukluğu Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Tekrar eden rahatsız edici anılarınız var mı?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 1, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Travmatik olayla ilgili kabus görür müsünüz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her gece"]'::jsonb, 2, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Olayı yeniden yaşıyormuş gibi hisseder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 3, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Travmayı hatırlatan durumlardan kaçınır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 4, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Travmatik olayın detaylarını hatırlamakta zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 5, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kendinizi veya geleceği suçlar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 6, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sürekli tetikte kalma hissi yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 7, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Aşırı irkilme tepkisi gösterir misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 8, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Uyku bozuklukları yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her gece"]'::jsonb, 9, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Travma sonrası yaşam kalitenizde düşüş oldu mu?', 'multiple_choice', '["Hiç olmadı", "Az oldu", "Orta düzeyde", "Çok oldu", "Tamamen bozuldu"]'::jsonb, 10, true
FROM tests WHERE title = 'Travma Sonrası Stres Bozukluğu Testi';

-- Sosyal Kaygı Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sosyal ortamlarda endişe yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 1, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Başkalarının sizi yargılayacağından korkar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 2, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Toplum içinde konuşmaktan kaçınır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 3, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sosyal durumlarda fiziksel belirtiler yaşar mısınız? (terleme, titreme vb.)', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 4, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Yeni insanlarla tanışmaktan kaçınır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 5, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Grup içinde dikkat çekmekten korkar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 6, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sosyal etkinliklere katılmaktan kaçınır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 7, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Eleştiri almaktan aşırı korkar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 8, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sosyal performansınızdan endişe duyar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 9, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sosyal kaygı günlük yaşamınızı etkiler mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Çok fazla"]'::jsonb, 10, true
FROM tests WHERE title = 'Sosyal Kaygı Testi';

-- Alkol Bağımlılığı Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Ne sıklıkla alkol tüketirsiniz?', 'multiple_choice', '["Hiç içmem", "Ayda bir", "Haftada bir", "Haftada birkaç kez", "Her gün"]'::jsonb, 1, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İçki içmeyi bırakmakta zorlanır mısınız?', 'multiple_choice', '["Hiç zorlanmam", "Az zorlanırım", "Orta düzeyde", "Çok zorlanırım", "İmkansız"]'::jsonb, 2, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Alkol almadığınızda fiziksel belirtiler yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 3, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Alkol kullanımınız işinizi etkiler mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 4, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İlişkileriniz alkol kullanımından etkilenir mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Çok fazla"]'::jsonb, 5, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Alkol alımınızı kontrol etmekte zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 6, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Alkol kullanımınız hakkında suçluluk hisseder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 7, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Sabah uyandığınızda içki içme ihtiyacı hisseder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her sabah"]'::jsonb, 8, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Alkol kullanımınızı gizlemeye çalışır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 9, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Alkol kullanımı yüzünden hafıza kayıpları yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sık sık"]'::jsonb, 10, true
FROM tests WHERE title = 'Alkol Bağımlılığı Testi';

-- Stres Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Günlük yaşamda stres hisseder misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 1, true
FROM tests WHERE title = 'Stres Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Stres karşısında fiziksel belirtiler yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 2, true
FROM tests WHERE title = 'Stres Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Stresle başa çıkmakta zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 3, true
FROM tests WHERE title = 'Stres Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İş yükünüz sizi strese sokar mı?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 4, true
FROM tests WHERE title = 'Stres Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Stres yüzünden uyku problemi yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her gece"]'::jsonb, 5, true
FROM tests WHERE title = 'Stres Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Stres yüzünden sinirlilik yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 6, true
FROM tests WHERE title = 'Stres Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Stres konsantrasyonunuzu etkiler mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Çok fazla"]'::jsonb, 7, true
FROM tests WHERE title = 'Stres Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Stres yüzünden kaçınma davranışları sergiler misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 8, true
FROM tests WHERE title = 'Stres Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Stres yönetimi konusunda kendinizi nasıl değerlendirirsiniz?', 'multiple_choice', '["Çok iyi", "İyi", "Orta", "Zayıf", "Çok zayıf"]'::jsonb, 9, true
FROM tests WHERE title = 'Stres Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Stres günlük aktivitelerinizi etkiler mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Çok fazla"]'::jsonb, 10, true
FROM tests WHERE title = 'Stres Testi';

-- Öfke Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Öfke nöbetleri yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 1, true
FROM tests WHERE title = 'Öfke Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Küçük şeyler sizi çok sinirlendiriri mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 2, true
FROM tests WHERE title = 'Öfke Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Öfkenizi kontrol etmekte zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 3, true
FROM tests WHERE title = 'Öfke Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Öfke anında saldırgan davranışlar sergiler misiniz?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Sürekli"]'::jsonb, 4, true
FROM tests WHERE title = 'Öfke Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Öfkelendiğinizde fiziksel belirtiler yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 5, true
FROM tests WHERE title = 'Öfke Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'İlişkileriniz öfkenizden etkilenir mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Çok fazla"]'::jsonb, 6, true
FROM tests WHERE title = 'Öfke Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Öfke sonrası pişmanlık yaşar mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 7, true
FROM tests WHERE title = 'Öfke Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Öfkenizi ifade etmekte zorlanır mısınız?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 8, true
FROM tests WHERE title = 'Öfke Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Başkalarının davranışları sizi kolayca öfkelendirir mi?', 'multiple_choice', '["Hiçbir zaman", "Nadiren", "Bazen", "Sık sık", "Her zaman"]'::jsonb, 9, true
FROM tests WHERE title = 'Öfke Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Öfke yönetimi konusunda yardıma ihtiyaç duyar mısınız?', 'multiple_choice', '["Hiç duymam", "Az duyarım", "Kararsızım", "Duyarım", "Kesinlikle duyarım"]'::jsonb, 10, true
FROM tests WHERE title = 'Öfke Testi';

-- Öz Güven Testi için sorular
INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kendinize güveniniz nasıl?', 'multiple_choice', '["Çok düşük", "Düşük", "Orta", "Yüksek", "Çok yüksek"]'::jsonb, 1, true
FROM tests WHERE title = 'Öz Güven Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Yeni durumlarla karşılaştığınızda kendinizi nasıl hissedersiniz?', 'multiple_choice', '["Çok endişeli", "Endişeli", "Kararsız", "Güvenli", "Çok güvenli"]'::jsonb, 2, true
FROM tests WHERE title = 'Öz Güven Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Başkalarının görüşlerinden ne kadar etkilenirsiniz?', 'multiple_choice', '["Çok fazla", "Fazla", "Orta", "Az", "Hiç"]'::jsonb, 3, true
FROM tests WHERE title = 'Öz Güven Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kendi yeteneklerinize güvenir misiniz?', 'multiple_choice', '["Hiç güvenmem", "Az güvenirim", "Orta düzeyde", "Güvenirim", "Çok güvenirim"]'::jsonb, 4, true
FROM tests WHERE title = 'Öz Güven Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Eleştiri karşısında nasıl tepki verirsiniz?', 'multiple_choice', '["Çok kötü", "Kötü", "Normal", "İyi", "Çok iyi"]'::jsonb, 5, true
FROM tests WHERE title = 'Öz Güven Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Risk almaktan korkar mısınız?', 'multiple_choice', '["Çok korkarım", "Korkarım", "Kararsızım", "Korkmam", "Hiç korkmam"]'::jsonb, 6, true
FROM tests WHERE title = 'Öz Güven Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Başarılarınızı nasıl değerlendirirsiniz?', 'multiple_choice', '["Şans eseri", "Biraz çabam", "Orta düzey", "Çabalarım", "Tamamen çabam"]'::jsonb, 7, true
FROM tests WHERE title = 'Öz Güven Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Kendinizi başkalarıyla karşılaştırır mısınız?', 'multiple_choice', '["Sürekli", "Sık sık", "Bazen", "Nadiren", "Hiçbir zaman"]'::jsonb, 8, true
FROM tests WHERE title = 'Öz Güven Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Hatalarınızı nasıl karşılarsınız?', 'multiple_choice', '["Çok kötü", "Kötü", "Normal", "İyi", "Öğrenme fırsatı"]'::jsonb, 9, true
FROM tests WHERE title = 'Öz Güven Testi';

INSERT INTO test_questions (test_id, question_text, question_type, options, step_number, is_required) 
SELECT id, 'Gelecek planlarınıza ne kadar güvenirsiniz?', 'multiple_choice', '["Hiç güvenmem", "Az güvenirim", "Orta düzeyde", "Güvenirim", "Çok güvenirim"]'::jsonb, 10, true
FROM tests WHERE title = 'Öz Güven Testi';
