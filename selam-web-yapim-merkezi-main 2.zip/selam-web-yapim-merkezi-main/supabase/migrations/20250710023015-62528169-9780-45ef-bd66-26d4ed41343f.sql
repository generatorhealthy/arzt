
-- Staff kullanıcılarının da uzman ekleyebilmesi için specialists tablosu politikalarını güncelle
DROP POLICY IF EXISTS "Admins can insert specialists" ON public.specialists;
DROP POLICY IF EXISTS "Admins can manage all specialists" ON public.specialists;
DROP POLICY IF EXISTS "Admins and staff can view all specialists" ON public.specialists;
DROP POLICY IF EXISTS "Admins and staff can insert specialists" ON public.specialists;
DROP POLICY IF EXISTS "Admins and staff can update specialists" ON public.specialists;
DROP POLICY IF EXISTS "Only admins can delete specialists" ON public.specialists;

-- Yeni politikalar: Staff ve Admin'ler uzman yönetimi yapabilir
CREATE POLICY "Admins and staff can view all specialists" 
ON public.specialists 
FOR SELECT 
USING (
  (is_active = true) OR 
  (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'staff'::user_role)
    AND user_profiles.is_approved = true
  ))
);

CREATE POLICY "Admins and staff can insert specialists" 
ON public.specialists 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'staff'::user_role)
    AND user_profiles.is_approved = true
  )
);

CREATE POLICY "Admins and staff can update specialists" 
ON public.specialists 
FOR UPDATE 
USING (
  (user_id = auth.uid()) OR 
  (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'staff'::user_role)
    AND user_profiles.is_approved = true
  ))
);

-- Sadece adminler uzman silebilir
CREATE POLICY "Only admins can delete specialists" 
ON public.specialists 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role = 'admin'::user_role
    AND user_profiles.is_approved = true
  )
);
