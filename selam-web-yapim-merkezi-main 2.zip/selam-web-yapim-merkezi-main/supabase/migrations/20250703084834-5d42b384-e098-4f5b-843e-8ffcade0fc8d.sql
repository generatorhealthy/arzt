
-- Storage bucket oluştur profil fotoğrafları için
INSERT INTO storage.buckets (id, name, public)
VALUES ('profile-pictures', 'profile-pictures', true);

-- Storage bucket için policy oluştur - herkes yükleyebilir
CREATE POLICY "Anyone can upload profile pictures" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'profile-pictures');

-- Herkes profil fotoğraflarını görebilir
CREATE POLICY "Anyone can view profile pictures" ON storage.objects
FOR SELECT USING (bucket_id = 'profile-pictures');

-- Herkes profil fotoğraflarını güncelleyebilir
CREATE POLICY "Anyone can update profile pictures" ON storage.objects
FOR UPDATE USING (bucket_id = 'profile-pictures');

-- Herkes profil fotoğraflarını silebilir
CREATE POLICY "Anyone can delete profile pictures" ON storage.objects
FOR DELETE USING (bucket_id = 'profile-pictures');

-- Specialists tablosuna eksik kolonları ekle
ALTER TABLE public.specialists 
ADD COLUMN IF NOT EXISTS certifications TEXT,
ADD COLUMN IF NOT EXISTS online_consultation BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS face_to_face_consultation BOOLEAN DEFAULT true;
