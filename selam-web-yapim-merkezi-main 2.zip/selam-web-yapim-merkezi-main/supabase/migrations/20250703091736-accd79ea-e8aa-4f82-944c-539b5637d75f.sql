
-- Önce mevcut kullanıcının durumunu kontrol et ve admin rolü ekle
-- Bu komutu çalıştırmadan önce admin kullanıcısının user_id'sini almalıyız

-- Şu an giriş yapmış kullanıcının admin rolüyle user_profiles'a eklenmesi için
-- Eğer yoksa admin kullanıcısını ekle
INSERT INTO public.user_profiles (user_id, role, is_approved)
SELECT auth.uid(), 'admin'::user_role, true
WHERE NOT EXISTS (
  SELECT 1 FROM public.user_profiles 
  WHERE user_id = auth.uid()
);

-- Eğer varsa ama admin değilse güncelle
UPDATE public.user_profiles 
SET role = 'admin'::user_role, is_approved = true 
WHERE user_id = auth.uid() AND role != 'admin'::user_role;
