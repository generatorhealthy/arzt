
-- Appointments tablosundaki verileri kontrol et
SELECT 
    id,
    patient_name,
    specialist_id,
    appointment_date,
    appointment_time,
    created_at
FROM public.appointments
ORDER BY created_at DESC
LIMIT 10;

-- Specialists tablosundaki verileri kontrol et
SELECT 
    id,
    name,
    specialty,
    is_active
FROM public.specialists
WHERE is_active = true
ORDER BY name;

-- Appointments ve specialists arasındaki ilişkiyi kontrol et
SELECT 
    a.id as appointment_id,
    a.patient_name,
    a.specialist_id,
    s.name as specialist_name,
    s.specialty
FROM public.appointments a
LEFT JOIN public.specialists s ON a.specialist_id = s.id
ORDER BY a.created_at DESC
LIMIT 10;
