
-- Önce mevcut politikaları kontrol et
SELECT 
    schemaname, 
    tablename, 
    policyname, 
    cmd, 
    roles,
    permissive,
    qual,
    with_check
FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'appointments'
ORDER BY policyname;

-- RLS durumunu kontrol et
SELECT 
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables 
WHERE schemaname = 'public' AND tablename = 'appointments';

-- Tüm appointments politikalarını sil
DROP POLICY IF EXISTS "allow_anonymous_insert" ON public.appointments;
DROP POLICY IF EXISTS "allow_authenticated_insert" ON public.appointments;
DROP POLICY IF EXISTS "allow_authenticated_select" ON public.appointments;
DROP POLICY IF EXISTS "allow_admin_all" ON public.appointments;
DROP POLICY IF EXISTS "allow_specialist_own" ON public.appointments;
DROP POLICY IF EXISTS "Public can insert appointments" ON public.appointments;
DROP POLICY IF EXISTS "Authenticated can select appointments" ON public.appointments;
DROP POLICY IF EXISTS "Admins full access" ON public.appointments;
DROP POLICY IF EXISTS "Specialists manage own appointments" ON public.appointments;
DROP POLICY IF EXISTS "allow_all_inserts" ON public.appointments;

-- RLS'yi kapat ve tekrar aç
ALTER TABLE public.appointments DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Sadece gerekli politikaları oluştur - en basit hali
CREATE POLICY "appointments_insert_policy" ON public.appointments
    FOR INSERT 
    WITH CHECK (true);

CREATE POLICY "appointments_select_policy" ON public.appointments
    FOR SELECT 
    USING (true);

-- Tekrar kontrol et
SELECT 
    schemaname, 
    tablename, 
    policyname, 
    cmd, 
    roles,
    permissive,
    qual,
    with_check
FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'appointments'
ORDER BY policyname;
