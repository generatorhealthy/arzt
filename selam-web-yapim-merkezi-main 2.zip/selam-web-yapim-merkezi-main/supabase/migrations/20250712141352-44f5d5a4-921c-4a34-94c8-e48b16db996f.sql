
-- Fix the security issue in generate_monthly_orders function
CREATE OR REPLACE FUNCTION public.generate_monthly_orders()
RETURNS void 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  auto_order RECORD;
  next_month INTEGER;
  order_date TIMESTAMPTZ;
BEGIN
  FOR auto_order IN 
    SELECT * FROM public.automatic_orders 
    WHERE is_active = true 
    AND current_month < total_months
  LOOP
    next_month := auto_order.current_month + 1;
    
    -- Calculate next order date
    order_date := auto_order.registration_date + INTERVAL '1 month' * (next_month - 1);
    
    -- Check if it's time to create the next month's order
    IF DATE_TRUNC('day', order_date) <= DATE_TRUNC('day', NOW()) 
       AND NOT (next_month = ANY(auto_order.paid_months)) THEN
      
      -- Create new order for next month
      INSERT INTO public.orders (
        customer_name,
        customer_email,
        customer_phone,
        package_name,
        package_type,
        amount,
        status,
        payment_method,
        customer_type,
        customer_address,
        customer_city,
        customer_tc_no,
        company_name,
        company_tax_no,
        company_tax_office,
        is_first_order,
        subscription_month,
        parent_order_id
      ) VALUES (
        auto_order.customer_name,
        auto_order.customer_email,
        auto_order.customer_phone,
        auto_order.package_name,
        auto_order.package_type,
        auto_order.amount,
        'pending',
        auto_order.payment_method,
        auto_order.customer_type,
        auto_order.customer_address,
        auto_order.customer_city,
        auto_order.customer_tc_no,
        auto_order.company_name,
        auto_order.company_tax_no,
        auto_order.company_tax_office,
        false,
        next_month,
        (SELECT id FROM public.orders WHERE customer_email = auto_order.customer_email AND is_first_order = true LIMIT 1)
      );
      
    END IF;
  END LOOP;
END;
$$;
