
-- User profiles tablosuna admin tarafından INSERT yapılabilmesi için policy ekle
CREATE POLICY "Admins can insert user profiles" 
ON public.user_profiles 
FOR INSERT 
TO authenticated 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles existing_profile
    WHERE existing_profile.user_id = auth.uid() 
    AND existing_profile.role = 'admin'
  )
);

-- Ayrıca kullanıcılar kendi profillerini görebilsin diye mevcut policy'yi güncelle
DROP POLICY IF EXISTS "Users can view their own profile" ON public.user_profiles;

CREATE POLICY "Users can view their own profile or admins can view all" 
ON public.user_profiles 
FOR SELECT 
TO authenticated 
USING (
  auth.uid() = user_id 
  OR EXISTS (
    SELECT 1 FROM public.user_profiles admin_profile
    WHERE admin_profile.user_id = auth.uid() 
    AND admin_profile.role = 'admin'
  )
);
