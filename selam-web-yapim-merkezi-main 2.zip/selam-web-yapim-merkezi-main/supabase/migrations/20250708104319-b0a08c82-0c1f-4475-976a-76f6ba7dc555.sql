
-- Appointments tablosunda RLS'yi geçici olarak devre dışı bırak
ALTER TABLE public.appointments DISABLE ROW LEVEL SECURITY;

-- Tüm mevcut politikaları temizle
DO $$ 
DECLARE
    r RECORD;
BEGIN
    FOR r IN (SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'appointments') LOOP
        EXECUTE 'DROP POLICY IF EXISTS "' || r.policyname || '" ON public.appointments';
    END LOOP;
END $$;

-- RLS'yi tekrar aktif et
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Basit ve çalışan politikalar oluştur
-- Anonymous kullanıcılar randevu oluşturabilir
CREATE POLICY "allow_anonymous_insert" ON public.appointments
    FOR INSERT 
    TO anon
    WITH CHECK (true);

-- Authenticated kullanıcılar randevu oluşturabilir
CREATE POLICY "allow_authenticated_insert" ON public.appointments
    FOR INSERT 
    TO authenticated
    WITH CHECK (true);

-- Authenticated kullanıcılar randevuları görüntüleyebilir
CREATE POLICY "allow_authenticated_select" ON public.appointments
    FOR SELECT 
    TO authenticated
    USING (true);

-- Admin kullanıcılar için tam erişim
CREATE POLICY "allow_admin_all" ON public.appointments
    FOR ALL 
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM user_profiles 
            WHERE user_profiles.user_id = auth.uid() 
            AND user_profiles.role = 'admin'::user_role
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM user_profiles 
            WHERE user_profiles.user_id = auth.uid() 
            AND user_profiles.role = 'admin'::user_role
        )
    );

-- Specialist kullanıcılar kendi randevularını yönetebilir
CREATE POLICY "allow_specialist_own" ON public.appointments
    FOR ALL 
    TO authenticated
    USING (
        specialist_id IN (
            SELECT id FROM specialists 
            WHERE user_id = auth.uid()
        )
    )
    WITH CHECK (
        specialist_id IN (
            SELECT id FROM specialists 
            WHERE user_id = auth.uid()
        )
    );

-- Politikaları kontrol et
SELECT 
    schemaname, 
    tablename, 
    policyname, 
    cmd, 
    roles,
    qual,
    with_check
FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'appointments'
ORDER BY policyname;
