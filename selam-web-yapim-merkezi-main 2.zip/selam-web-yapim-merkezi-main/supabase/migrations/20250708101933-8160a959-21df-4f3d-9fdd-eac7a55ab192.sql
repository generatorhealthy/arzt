
-- Appointments tablosunda RLS'yi tamamen kapat
ALTER TABLE public.appointments DISABLE ROW LEVEL SECURITY;

-- Tüm mevcut politikaları sil
DROP POLICY IF EXISTS "Allow anonymous inserts" ON public.appointments;
DROP POLICY IF EXISTS "Allow authenticated select" ON public.appointments;
DROP POLICY IF EXISTS "Allow admin all operations" ON public.appointments;
DROP POLICY IF EXISTS "Allow specialist own appointments" ON public.appointments;

-- RLS'yi tekrar aç
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Herkes için INSERT politikası (anonymous dahil) - en basit hali
CREATE POLICY "Public can insert appointments" ON public.appointments
  FOR INSERT
  WITH CHECK (true);

-- Authenticated kullanıcılar için SELECT
CREATE POLICY "Authenticated can select appointments" ON public.appointments
  FOR SELECT
  TO authenticated
  USING (true);

-- Adminler için tüm işlemler
CREATE POLICY "Admins full access" ON public.appointments
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role = 'admin'::user_role
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role = 'admin'::user_role
  ));

-- Specialists kendi randevularını görebilir/yönetebilir
CREATE POLICY "Specialists manage own appointments" ON public.appointments
  FOR ALL
  TO authenticated
  USING (specialist_id IN (
    SELECT specialists.id FROM specialists 
    WHERE specialists.user_id = auth.uid()
  ))
  WITH CHECK (specialist_id IN (
    SELECT specialists.id FROM specialists 
    WHERE specialists.user_id = auth.uid()
  ));

-- Kontrol et
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'appointments'
ORDER BY policyname;
