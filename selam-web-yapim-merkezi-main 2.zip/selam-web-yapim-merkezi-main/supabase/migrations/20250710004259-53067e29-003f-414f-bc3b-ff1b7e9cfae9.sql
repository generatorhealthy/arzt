
-- user_role enum'ına staff rolünü ekle
ALTER TYPE public.user_role ADD VALUE 'staff';
