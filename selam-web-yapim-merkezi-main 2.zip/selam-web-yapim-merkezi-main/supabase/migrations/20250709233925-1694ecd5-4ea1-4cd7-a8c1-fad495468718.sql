
-- Add email tracking to orders table to prevent duplicate contract emails
ALTER TABLE public.orders 
ADD COLUMN contract_emails_sent BOOLEAN DEFAULT false,
ADD COLUMN is_first_order BOOLEAN DEFAULT true,
ADD COLUMN subscription_month INTEGER DEFAULT 1,
ADD COLUMN parent_order_id UUID REFERENCES public.orders(id);

-- Create automatic orders table for tracking recurring payments
CREATE TABLE public.automatic_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_email TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT,
  package_name TEXT NOT NULL,
  package_type TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  payment_method TEXT NOT NULL,
  customer_type TEXT NOT NULL DEFAULT 'individual',
  customer_address TEXT,
  customer_city TEXT,
  customer_tc_no TEXT,
  company_name TEXT,
  company_tax_no TEXT,
  company_tax_office TEXT,
  registration_date TIMESTAMPTZ NOT NULL,
  monthly_payment_day INTEGER NOT NULL,
  total_months INTEGER NOT NULL DEFAULT 24,
  paid_months INTEGER[] DEFAULT '{}',
  current_month INTEGER DEFAULT 1,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS for automatic_orders
ALTER TABLE public.automatic_orders ENABLE ROW LEVEL SECURITY;

-- Policies for automatic_orders
CREATE POLICY "Admin can manage automatic orders" ON public.automatic_orders
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM user_profiles 
  WHERE user_id = auth.uid() 
  AND role = 'admin'::user_role 
  AND is_approved = true
));

CREATE POLICY "Public can view automatic orders" ON public.automatic_orders
FOR SELECT
USING (true);

-- Function to create automatic order schedule when first order is approved
CREATE OR REPLACE FUNCTION create_automatic_order_schedule()
RETURNS TRIGGER AS $$
BEGIN
  -- Only create schedule if this is the first order and it's being approved
  IF NEW.status = 'approved' AND OLD.status != 'approved' AND NEW.is_first_order = true THEN
    INSERT INTO public.automatic_orders (
      customer_email,
      customer_name,
      customer_phone,
      package_name,
      package_type,
      amount,
      payment_method,
      customer_type,
      customer_address,
      customer_city,
      customer_tc_no,
      company_name,
      company_tax_no,
      company_tax_office,
      registration_date,
      monthly_payment_day,
      paid_months
    ) VALUES (
      NEW.customer_email,
      NEW.customer_name,
      NEW.customer_phone,
      NEW.package_name,
      NEW.package_type,
      NEW.amount,
      NEW.payment_method,
      NEW.customer_type,
      NEW.customer_address,
      NEW.customer_city,
      NEW.customer_tc_no,
      NEW.company_name,
      NEW.company_tax_no,
      NEW.company_tax_office,
      NEW.created_at,
      EXTRACT(DAY FROM NEW.created_at),
      ARRAY[1] -- First month is paid
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic order scheduling
CREATE TRIGGER trigger_create_automatic_order_schedule
  AFTER UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION create_automatic_order_schedule();

-- Function to generate monthly orders
CREATE OR REPLACE FUNCTION generate_monthly_orders()
RETURNS void AS $$
DECLARE
  auto_order RECORD;
  next_month INTEGER;
  order_date TIMESTAMPTZ;
BEGIN
  FOR auto_order IN 
    SELECT * FROM public.automatic_orders 
    WHERE is_active = true 
    AND current_month < total_months
  LOOP
    next_month := auto_order.current_month + 1;
    
    -- Calculate next order date
    order_date := auto_order.registration_date + INTERVAL '1 month' * (next_month - 1);
    
    -- Check if it's time to create the next month's order
    IF DATE_TRUNC('day', order_date) <= DATE_TRUNC('day', NOW()) 
       AND NOT (next_month = ANY(auto_order.paid_months)) THEN
      
      -- Create new order for next month
      INSERT INTO public.orders (
        customer_name,
        customer_email,
        customer_phone,
        package_name,
        package_type,
        amount,
        status,
        payment_method,
        customer_type,
        customer_address,
        customer_city,
        customer_tc_no,
        company_name,
        company_tax_no,
        company_tax_office,
        is_first_order,
        subscription_month,
        parent_order_id
      ) VALUES (
        auto_order.customer_name,
        auto_order.customer_email,
        auto_order.customer_phone,
        auto_order.package_name,
        auto_order.package_type,
        auto_order.amount,
        'pending',
        auto_order.payment_method,
        auto_order.customer_type,
        auto_order.customer_address,
        auto_order.customer_city,
        auto_order.customer_tc_no,
        auto_order.company_name,
        auto_order.company_tax_no,
        auto_order.company_tax_office,
        false,
        next_month,
        (SELECT id FROM public.orders WHERE customer_email = auto_order.customer_email AND is_first_order = true LIMIT 1)
      );
      
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;
