
-- Update the RLS policy for creating orders to be more permissive
DROP POLICY IF EXISTS "Anyone can create orders" ON public.orders;

CREATE POLICY "Anyone can create orders" 
  ON public.orders 
  FOR INSERT 
  WITH CHECK (true);

-- Also ensure the table has the correct permissions
GRANT INSERT ON public.orders TO anon;
GRANT INSERT ON public.orders TO authenticated;
