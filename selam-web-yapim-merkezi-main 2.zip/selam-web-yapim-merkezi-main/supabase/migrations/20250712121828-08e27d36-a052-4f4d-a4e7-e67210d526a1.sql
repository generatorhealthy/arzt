
-- Add notes column to legal_proceedings table
ALTER TABLE public.legal_proceedings 
ADD COLUMN notes TEXT;
