
-- Ön bilgilendirme formu içeriğini saklamak için tablo oluştur
CREATE TABLE public.form_contents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  form_type TEXT NOT NULL UNIQUE,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- RLS'yi etkinleştir
ALTER TABLE public.form_contents ENABLE ROW LEVEL SECURITY;

-- Admin ve staff'ın form içeriklerini yönetebilmesi için policy
CREATE POLICY "Admin and staff can manage form contents" ON public.form_contents
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'staff') 
    AND is_approved = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'staff') 
    AND is_approved = true
  )
);

-- Herkesin form içeriklerini okuyabilmesi için policy (checkout için gerekli)
CREATE POLICY "Anyone can read form contents" ON public.form_contents
FOR SELECT
USING (true);

-- Varsayılan ön bilgilendirme formu içeriğini ekle
INSERT INTO public.form_contents (form_type, content) VALUES 
('pre_info', 'DOKTORUM OL ÜYELİK SÖZLEŞMESİ

1. HİZMET ALAN''IN ÜYELİK PAKETİ VE ÖZELLİKLERİ
1.1 Bu Sözleşme gereği, Hizmet Alan, Üyelik hizmetleri dahilinde Doktorum Ol tarafından sunulan hizmetleri, talep ettiği şekilde almayı kabul eder ve beyan eder. Doktorum Ol, bu Sözleşme çerçevesinde Hizmet Alan''a satın aldığı abonelikte bulunan hizmetleri sunmayı taahhüt eder.

1.2 İşbu Sözleşme uyarınca Hizmet Alan''ın;

2. TARAFLAR
Bu Sözleşme çerçevesinde, Doktorum Ol Sitesi ve Hizmet Alan birlikte "Taraflar" olarak adlandırılacaktır.

3. AMAÇ VE KONU
Bu sözleşmenin temel amacı, Doktorum Ol''un Premium Üyelik hizmetlerinden faydalanmak isteyen kişi adına Doktorum Ol tarafından www.doktorumol.com.tr alan adındaki web sitesinde bir profil oluşturulmasıdır.

4. TANIMLAR
İşbu Sözleşmedeki tanımlar aşağıdaki gibidir;

Fikri Mülkiyet Doktorum Ol''un sahip olduğu veya kullanıldığı veya işlerinin yürütülmesi için gerekli olan dünya çapında mevcut veya gelecekte mevcut olabilecek her türlü ticaret markasını, ticari unvanı, hizmet markasını, patentleri, ticaret, faaliyet ve alan adlarını, URL''leri, tasarımları, telif hakları, know-how, ticari sırlar ve bunlara gibi, patent edilebilir olsun veya olmasın), veya diğer endüstriyel veya fikri mülkiyet haklarını, lisanslarını, markalarını, patentleri, faydalı modelleri ve endüstriyel tasarım haklarını, ve bunlarla ilgili başvuruları, herhangi bir hukuki koruma altında olan veya olmayan her türlü buluş, geliştirmeyi, iyileştirmeyi, keşfi, know-how''ı, telif hakkını, kavram ve düşünceyi, her türlü ticari sırrı, herhangi bir hukuki koruma altında olan veya olmayan her türlü bilgisayar programı ve yazılımı (sanatsal, teknik ve tasarım dokümanları, algoritmalar, kaynak kodları, nesne kodları vs.) ve çok medya içeriklerini, veritabanları, grafik ve tasarım materyalini de dahil olmak üzere tüm eserlerini ifade eder.')
ON CONFLICT (form_type) DO NOTHING;
