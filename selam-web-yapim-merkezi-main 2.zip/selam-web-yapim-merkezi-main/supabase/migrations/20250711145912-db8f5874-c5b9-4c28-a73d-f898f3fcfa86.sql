
-- automatic_orders tablosuna customer_email için unique constraint ekle
ALTER TABLE public.automatic_orders 
ADD CONSTRAINT unique_customer_email UNIQUE (customer_email);
