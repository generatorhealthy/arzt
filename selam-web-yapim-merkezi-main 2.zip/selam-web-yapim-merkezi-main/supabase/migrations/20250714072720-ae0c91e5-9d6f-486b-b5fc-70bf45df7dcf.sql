-- Update RLS policies for blog_posts to include staff role
-- Drop existing policy
DROP POLICY IF EXISTS "Specialists and admins can create blog posts" ON public.blog_posts;

-- Create a new policy that allows specialists, admins, and staff to create blog posts
CREATE POLICY "Specialists, admins and staff can create blog posts" 
ON public.blog_posts 
FOR INSERT 
WITH CHECK (
  (author_id = auth.uid()) AND 
  (
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role = 'specialist'::user_role
    ) OR
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role = 'admin'::user_role
    ) OR
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role = 'staff'::user_role
    )
  )
);