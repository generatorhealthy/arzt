
-- Enable pg_cron and pg_net extensions for scheduled tasks
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Create a cron job that runs daily at 9:00 AM to generate monthly orders
SELECT cron.schedule(
  'generate-monthly-orders-daily',
  '0 9 * * *', -- Every day at 9:00 AM
  $$
  SELECT
    net.http_post(
        url:='https://irnfwewabogveofwemvg.supabase.co/functions/v1/generate-monthly-orders',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlybmZ3ZXdhYm9ndmVvZndlbXZnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE0MjUzMTAsImV4cCI6MjA2NzAwMTMxMH0.yK3oE_n2a4Y7RcHbeOC2_T_OE-jXcCip2C9QLweRJqs"}'::jsonb,
        body:='{"scheduled": true}'::jsonb
    ) as request_id;
  $$
);

-- Update the generate_monthly_orders function to be more efficient
CREATE OR REPLACE FUNCTION public.generate_monthly_orders()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  auto_order RECORD;
  next_month INTEGER;
  order_date DATE;
  orders_created INTEGER := 0;
  result_json json;
BEGIN
  FOR auto_order IN 
    SELECT * FROM public.automatic_orders 
    WHERE is_active = true 
    AND array_length(paid_months, 1) < total_months
  LOOP
    -- Find the next unpaid month
    next_month := 1;
    WHILE next_month <= auto_order.total_months AND next_month = ANY(auto_order.paid_months) LOOP
      next_month := next_month + 1;
    END LOOP;
    
    -- Skip if all months are paid
    IF next_month > auto_order.total_months THEN
      CONTINUE;
    END IF;
    
    -- Calculate the due date for this month
    order_date := (auto_order.registration_date + INTERVAL '1 month' * (next_month - 1))::date;
    
    -- Set the day to the monthly payment day
    IF auto_order.monthly_payment_day <= 28 THEN
      order_date := date_trunc('month', order_date) + INTERVAL '1 month' - INTERVAL '1 day' + INTERVAL '1 day' * auto_order.monthly_payment_day;
    ELSE
      -- Handle end of month cases
      order_date := date_trunc('month', order_date) + INTERVAL '2 month' - INTERVAL '1 day';
    END IF;
    
    -- Check if it's time to create the order (today or overdue)
    IF order_date <= CURRENT_DATE THEN
      -- Check if order already exists for this month
      IF NOT EXISTS (
        SELECT 1 FROM public.orders 
        WHERE customer_email = auto_order.customer_email 
        AND subscription_month = next_month
        AND parent_order_id IS NOT NULL
      ) THEN
        -- Create new order for next month
        INSERT INTO public.orders (
          customer_name,
          customer_email,
          customer_phone,
          package_name,
          package_type,
          amount,
          status,
          payment_method,
          customer_type,
          customer_address,
          customer_city,
          customer_tc_no,
          company_name,
          company_tax_no,
          company_tax_office,
          is_first_order,
          subscription_month,
          parent_order_id
        ) VALUES (
          auto_order.customer_name,
          auto_order.customer_email,
          auto_order.customer_phone,
          auto_order.package_name,
          auto_order.package_type,
          auto_order.amount,
          'pending',
          auto_order.payment_method,
          auto_order.customer_type,
          auto_order.customer_address,
          auto_order.customer_city,
          auto_order.customer_tc_no,
          auto_order.company_name,
          auto_order.company_tax_no,
          auto_order.company_tax_office,
          false,
          next_month,
          (SELECT id FROM public.orders WHERE customer_email = auto_order.customer_email AND is_first_order = true LIMIT 1)
        );
        
        orders_created := orders_created + 1;
      END IF;
    END IF;
  END LOOP;
  
  -- Return result as JSON
  result_json := json_build_object(
    'success', true,
    'orders_created', orders_created,
    'timestamp', now()
  );
  
  RETURN result_json;
END;
$$;

-- Update the trigger to handle automatic order scheduling when first order is approved
CREATE OR REPLACE FUNCTION public.create_automatic_order_schedule()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Only create schedule if this is the first order and it's being approved
  IF NEW.status = 'approved' AND OLD.status != 'approved' AND NEW.is_first_order = true THEN
    INSERT INTO public.automatic_orders (
      customer_email,
      customer_name,
      customer_phone,
      package_name,
      package_type,
      amount,
      payment_method,
      customer_type,
      customer_address,
      customer_city,
      customer_tc_no,
      company_name,
      company_tax_no,
      company_tax_office,
      registration_date,
      monthly_payment_day,
      paid_months
    ) VALUES (
      NEW.customer_email,
      NEW.customer_name,
      NEW.customer_phone,
      NEW.package_name,
      NEW.package_type,
      NEW.amount,
      NEW.payment_method,
      NEW.customer_type,
      NEW.customer_address,
      NEW.customer_city,
      NEW.customer_tc_no,
      NEW.company_name,
      NEW.company_tax_no,
      NEW.company_tax_office,
      NEW.created_at,
      EXTRACT(DAY FROM NEW.created_at),
      ARRAY[1] -- First month is paid
    )
    ON CONFLICT (customer_email) DO UPDATE SET
      paid_months = CASE 
        WHEN NOT (1 = ANY(automatic_orders.paid_months)) 
        THEN array_append(automatic_orders.paid_months, 1)
        ELSE automatic_orders.paid_months
      END;
  END IF;
  
  RETURN NEW;
END;
$$;
