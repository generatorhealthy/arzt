
-- Personel bilgilerini güncelle
UPDATE public.employee_salaries 
SET 
  employee_surname = 'Hanım',
  base_salary = 22104
WHERE employee_name = 'Yağmur';

UPDATE public.employee_salaries 
SET 
  employee_surname = 'Hanım', 
  base_salary = 22104
WHERE employee_name = 'Fatıma';
