
-- Reviews tablosu zaten mevcut, sadece kontrol edelim ve gerekirse düzenleyelim
-- Eğer reviews tablosu yoksa oluşturalım, varsa geç
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'reviews') THEN
        CREATE TABLE public.reviews (
            id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
            specialist_id UUID NOT NULL REFERENCES public.specialists(id) ON DELETE CASCADE,
            reviewer_name TEXT NOT NULL,
            reviewer_email TEXT NOT NULL,
            rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
            comment TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- RLS politikalarını ekle
        ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

        -- Herkes onaylanmış yorumları görebilir
        CREATE POLICY "Anyone can view approved reviews" ON public.reviews
            FOR SELECT USING (status = 'approved');

        -- Herkes yorum ekleyebilir (pending durumunda)
        CREATE POLICY "Anyone can create reviews" ON public.reviews
            FOR INSERT WITH CHECK (status = 'pending');

        -- Sadece adminler tüm yorumları yönetebilir
        CREATE POLICY "Admins can manage all reviews" ON public.reviews
            FOR ALL USING (
                EXISTS (
                    SELECT 1 FROM public.user_profiles 
                    WHERE user_id = auth.uid() AND role = 'admin'
                )
            );
    END IF;
END $$;
