
-- Add referral_count column to client_referrals table
ALTER TABLE public.client_referrals 
ADD COLUMN referral_count INTEGER NOT NULL DEFAULT 0;

-- Update existing records to have referral_count = 1 where is_referred = true
UPDATE public.client_referrals 
SET referral_count = CASE WHEN is_referred = true THEN 1 ELSE 0 END;
