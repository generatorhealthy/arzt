
-- Önce mevcut problematik politikaları temizleyelim
DROP POLICY IF EXISTS "Users can view their own profile" ON public.user_profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Admin users can view all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Staff users can view all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Admins can delete all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Admin and Staff can update profiles" ON public.user_profiles;

-- get_current_user_role fonksiyonunu tamamen yeniden yazalım
DROP FUNCTION IF EXISTS public.get_current_user_role();

CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS text
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public', 'auth'
AS $function$
BEGIN
  RETURN (
    SELECT role::text 
    FROM public.user_profiles 
    WHERE user_id = auth.uid()
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'user';
END;
$function$;

-- Basit ve güvenli politikalar oluşturalım
-- Kullanıcılar kendi profillerini görebilir
CREATE POLICY "Users can view their own profile" 
ON public.user_profiles 
FOR SELECT 
TO authenticated 
USING (auth.uid() = user_id);

-- Admin kullanıcılar tüm profilleri görebilir (recursion olmadan)
CREATE POLICY "Admins can view all profiles" 
ON public.user_profiles 
FOR SELECT 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles up 
    WHERE up.user_id = auth.uid() 
    AND up.role = 'admin'
  ) 
  OR auth.uid() = user_id
);

-- Staff kullanıcılar tüm profilleri görebilir
CREATE POLICY "Staff can view all profiles" 
ON public.user_profiles 
FOR SELECT 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles up 
    WHERE up.user_id = auth.uid() 
    AND up.role = 'staff'
  ) 
  OR auth.uid() = user_id
);

-- Admin güncelleyebilir 
CREATE POLICY "Admins can update all profiles" 
ON public.user_profiles 
FOR UPDATE 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles up 
    WHERE up.user_id = auth.uid() 
    AND up.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles up 
    WHERE up.user_id = auth.uid() 
    AND up.role = 'admin'
  )
);

-- Admin silebilir
CREATE POLICY "Admins can delete all profiles" 
ON public.user_profiles 
FOR DELETE 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles up 
    WHERE up.user_id = auth.uid() 
    AND up.role = 'admin'
  )
);

-- Staff güncelleyebilir
CREATE POLICY "Staff can update profiles" 
ON public.user_profiles 
FOR UPDATE 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles up 
    WHERE up.user_id = auth.uid() 
    AND up.role = 'staff'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles up 
    WHERE up.user_id = auth.uid() 
    AND up.role = 'staff'
  )
);

-- Service role ve authenticated users için insert politikaları
CREATE POLICY "Service role can insert profiles" 
ON public.user_profiles 
FOR INSERT 
TO service_role 
WITH CHECK (true);

CREATE POLICY "Authenticated users can insert their own profile" 
ON public.user_profiles 
FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid() = user_id);
