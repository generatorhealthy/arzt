
-- user_role enum'ına 'legal' değerini ekle
ALTER TYPE public.user_role ADD VALUE 'legal';

-- Legal kullanıcılarının legal_proceedings tablosuna erişim politikalarını güncelle
DROP POLICY IF EXISTS "Admin can manage legal proceedings" ON public.legal_proceedings;

-- Yeni politika: Admin ve Legal kullanıcıları icralıkları yönetebilir
CREATE POLICY "Admin and Legal can manage legal proceedings" 
ON public.legal_proceedings 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'legal'::user_role)
    AND user_profiles.is_approved = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'legal'::user_role)
    AND user_profiles.is_approved = true
  )
);
