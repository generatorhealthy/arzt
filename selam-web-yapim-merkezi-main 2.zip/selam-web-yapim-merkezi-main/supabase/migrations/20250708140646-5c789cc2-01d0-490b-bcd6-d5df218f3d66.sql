
-- Create orders table to store real payment data
CREATE TABLE public.orders (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  customer_phone text,
  package_name text NOT NULL,
  package_type text NOT NULL, -- 'basic' or 'premium'
  amount numeric NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  payment_method text NOT NULL, -- 'credit_card' or 'bank_transfer'
  payment_transaction_id text,
  customer_type text NOT NULL DEFAULT 'individual', -- 'individual' or 'company'
  customer_address text,
  customer_city text,
  customer_tc_no text,
  company_name text,
  company_tax_no text,
  company_tax_office text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  approved_at timestamp with time zone,
  approved_by uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Create policy for admins to manage all orders
CREATE POLICY "Admins can manage all orders" 
  ON public.orders 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role = 'admin'::user_role
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role = 'admin'::user_role
    )
  );

-- Create policy to allow inserting orders (for checkout process)
CREATE POLICY "Anyone can create orders" 
  ON public.orders 
  FOR INSERT 
  WITH CHECK (true);
