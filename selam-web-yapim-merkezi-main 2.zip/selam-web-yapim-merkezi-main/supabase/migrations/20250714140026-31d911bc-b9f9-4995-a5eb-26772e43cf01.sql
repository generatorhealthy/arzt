
-- Kullanıcıların kendi rollerini değiştirmelerini engelleyen RLS politikası ekle
DROP POLICY IF EXISTS "Users cannot change their own role" ON public.user_profiles;

CREATE POLICY "Users cannot change their own role" 
ON public.user_profiles 
FOR UPDATE 
USING (
  -- Kullanıcı kendi profil bilgilerini güncelleyebilir ama rolünü değiştiremez
  (auth.uid() = user_id AND role = (SELECT role FROM public.user_profiles WHERE user_id = auth.uid()))
  OR 
  -- Admin ve staff kullanıcıları diğer kullanıcıların rollerini değiştirebilir
  (get_current_user_role() IN ('admin', 'staff'))
)
WITH CHECK (
  -- Kullanıcı kendi rolünü değiştiremez
  (auth.uid() = user_id AND role = (SELECT role FROM public.user_profiles WHERE user_id = auth.uid()))
  OR 
  -- Admin ve staff kullanıcıları rolleri değiştirebilir
  (get_current_user_role() IN ('admin', 'staff'))
);

-- Güvenli kullanıcı yönetimi için edge function ile kullanılacak RLS politikası
CREATE OR REPLACE FUNCTION public.can_manage_users(target_user_id uuid DEFAULT NULL)
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  current_user_role TEXT;
  current_user_approved BOOLEAN;
BEGIN
  -- Mevcut kullanıcının rolünü ve onay durumunu al
  SELECT role::text, is_approved INTO current_user_role, current_user_approved
  FROM public.user_profiles 
  WHERE user_id = auth.uid();
  
  -- Admin veya staff ise ve onaylı ise işlem yapabilir
  IF current_user_role IN ('admin', 'staff') AND current_user_approved = true THEN
    RETURN true;
  END IF;
  
  RETURN false;
EXCEPTION
  WHEN OTHERS THEN
    RETURN false;
END;
$function$;
