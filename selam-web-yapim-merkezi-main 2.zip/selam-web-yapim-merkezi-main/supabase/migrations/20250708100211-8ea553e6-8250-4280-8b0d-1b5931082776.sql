
-- Tüm mevcut politikaları silelim
DROP POLICY IF EXISTS "Anyone can create appointments" ON public.appointments;
DROP POLICY IF EXISTS "Admins can manage all appointments" ON public.appointments;
DROP POLICY IF EXISTS "Specialists can manage their own appointments" ON public.appointments;

-- RLS'yi geçici olarak kapatıp tekrar açalım
ALTER TABLE public.appointments DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Sadece INSERT için basit bir politika oluşturalım
CREATE POLICY "Allow all inserts" 
  ON public.appointments 
  FOR INSERT 
  TO public
  WITH CHECK (true);

-- Diğer gerekli politikaları da ekleyelim
CREATE POLICY "Admins can manage all appointments" 
  ON public.appointments 
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role = 'admin'::user_role
  ));

CREATE POLICY "Specialists can manage their own appointments" 
  ON public.appointments 
  FOR ALL
  TO authenticated
  USING (specialist_id IN (
    SELECT specialists.id FROM specialists 
    WHERE specialists.user_id = auth.uid()
  ));

-- Politikaları kontrol edelim
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'appointments'
ORDER BY policyname;
