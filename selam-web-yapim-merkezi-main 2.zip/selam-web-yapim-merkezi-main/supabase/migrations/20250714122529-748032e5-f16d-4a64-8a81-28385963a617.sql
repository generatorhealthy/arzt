
-- Fix the security issue in create_automatic_order_schedule function
CREATE OR REPLACE FUNCTION public.create_automatic_order_schedule()
RETURNS trigger 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Only create schedule if this is the first order and it's being approved
  IF NEW.status = 'approved' AND OLD.status != 'approved' AND NEW.is_first_order = true THEN
    INSERT INTO public.automatic_orders (
      customer_email,
      customer_name,
      customer_phone,
      package_name,
      package_type,
      amount,
      payment_method,
      customer_type,
      customer_address,
      customer_city,
      customer_tc_no,
      company_name,
      company_tax_no,
      company_tax_office,
      registration_date,
      monthly_payment_day,
      paid_months
    ) VALUES (
      NEW.customer_email,
      NEW.customer_name,
      NEW.customer_phone,
      NEW.package_name,
      NEW.package_type,
      NEW.amount,
      NEW.payment_method,
      NEW.customer_type,
      NEW.customer_address,
      NEW.customer_city,
      NEW.customer_tc_no,
      NEW.company_name,
      NEW.company_tax_no,
      NEW.company_tax_office,
      NEW.created_at,
      EXTRACT(DAY FROM NEW.created_at),
      ARRAY[1] -- First month is paid
    );
  END IF;
  
  RETURN NEW;
END;
$$;
