
-- Admin kullanıcıların specialist tablosuna veri ekleyebilmesi için policy'yi güncelle
DROP POLICY IF EXISTS "Admins can insert specialists" ON public.specialists;

CREATE POLICY "Admins can insert specialists" 
ON public.specialists 
FOR INSERT 
TO authenticated 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
);

-- Eğer mevcut "Admins can manage all specialists" policy'si varsa onu da güncelle
DROP POLICY IF EXISTS "Admins can manage all specialists" ON public.specialists;

CREATE POLICY "Admins can manage all specialists" 
ON public.specialists 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
);
