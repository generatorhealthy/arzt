-- Allow admins and staff to update published blog posts
-- Drop existing update policy for blog posts
DROP POLICY IF EXISTS "Doctors can update their own blog posts" ON public.blog_posts;

-- Create new policy allowing admins and staff to update any blog post, and specialists to update their own drafts/revision_needed posts
CREATE POLICY "Blog posts update policy" 
ON public.blog_posts 
FOR UPDATE 
USING (
  -- Admins and staff can update any blog post
  (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role = ANY(ARRAY['admin'::user_role, 'staff'::user_role])
  )) OR
  -- Specialists can only update their own non-published posts
  ((author_id = auth.uid()) AND (status = ANY (ARRAY['draft'::text, 'revision_needed'::text])))
)
WITH CHECK (
  -- Same conditions for WITH CHECK
  (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role = ANY(ARRAY['admin'::user_role, 'staff'::user_role])
  )) OR
  ((author_id = auth.uid()) AND (status = ANY (ARRAY['draft'::text, 'revision_needed'::text, 'pending'::text])))
);