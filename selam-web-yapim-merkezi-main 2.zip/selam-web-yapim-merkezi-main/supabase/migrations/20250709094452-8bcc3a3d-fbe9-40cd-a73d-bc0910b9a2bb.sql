
-- Önce mevcut tüm politikaları silelim
DROP POLICY IF EXISTS "Allow all order insertions" ON public.orders;
DROP POLICY IF EXISTS "Admins can manage all orders" ON public.orders;
DROP POLICY IF EXISTS "Anyone can create orders" ON public.orders;
DROP POLICY IF EXISTS "Enable insert for all users" ON public.orders;

-- RLS'yi geçici olarak kapatıp tekrar açalım
ALTER TABLE public.orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Tamamen açık bir INSERT politikası oluşturalım
CREATE POLICY "Public can insert orders" 
  ON public.orders 
  FOR INSERT 
  TO public
  WITH CHECK (true);

-- Admin politikasını da ekleyelim
CREATE POLICY "Admins can manage all orders" 
  ON public.orders 
  FOR ALL 
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role = 'admin'::user_role
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role = 'admin'::user_role
    )
  );

-- Gerekli izinleri verelim
GRANT INSERT ON public.orders TO anon;
GRANT INSERT ON public.orders TO authenticated;
GRANT INSERT ON public.orders TO public;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO public;
