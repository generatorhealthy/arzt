
-- Başarı istatistikleri tablosu
CREATE TABLE public.success_statistics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_name TEXT NOT NULL,
  employee_surname TEXT NOT NULL,
  specialists_registered INTEGER NOT NULL DEFAULT 0,
  month INTEGER NOT NULL,
  year INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE(employee_name, employee_surname, month, year)
);

-- İcralıklar tablosu
CREATE TABLE public.legal_proceedings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_name TEXT NOT NULL,
  unpaid_months INTEGER NOT NULL,
  total_months INTEGER NOT NULL,
  proceeding_amount DECIMAL(10,2) NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('İCRA_AÇILDI', 'İTİRAZ_ETTİ', 'DAVA_AÇILDI')),
  is_paid BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- RLS politikaları
ALTER TABLE public.success_statistics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.legal_proceedings ENABLE ROW LEVEL SECURITY;

-- Başarı istatistikleri için RLS politikaları
CREATE POLICY "Admin can manage success statistics" 
  ON public.success_statistics 
  FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'::user_role 
    AND is_approved = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'::user_role 
    AND is_approved = true
  ));

CREATE POLICY "Staff can view success statistics" 
  ON public.success_statistics 
  FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin'::user_role, 'staff'::user_role) 
    AND is_approved = true
  ));

-- İcralıklar için RLS politikaları (sadece admin görebilir)
CREATE POLICY "Admin can manage legal proceedings" 
  ON public.legal_proceedings 
  FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'::user_role 
    AND is_approved = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'::user_role 
    AND is_approved = true
  ));
