
-- Add 'legal' to the user_role enum
ALTER TYPE public.user_role ADD VALUE 'legal';
