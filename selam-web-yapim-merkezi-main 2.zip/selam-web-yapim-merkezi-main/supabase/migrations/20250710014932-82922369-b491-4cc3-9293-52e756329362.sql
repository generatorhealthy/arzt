
-- Tüm problematik politikaları tamamen temizleyelim ve basit çözüm uygulayalım
DROP POLICY IF EXISTS "Users can view their own profile" ON public.user_profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Staff can view all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Admin users can view all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Staff users can view all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Staff can update profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Admin and Staff can update profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "Admins can delete all profiles" ON public.user_profiles;

-- get_current_user_role fonksiyonunu tamamen yeniden yazalım - döngüsel başvuru olmadan
DROP FUNCTION IF EXISTS public.get_current_user_role();

CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS text
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  user_role TEXT;
BEGIN
  -- Direct query without RLS to avoid recursion
  SELECT role::text INTO user_role
  FROM public.user_profiles 
  WHERE user_id = auth.uid();
  
  RETURN COALESCE(user_role, 'user');
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'user';
END;
$function$;

-- Çok basit politikalar oluşturalım
-- 1. Kullanıcılar kendi profillerini görebilir
CREATE POLICY "Users can view own profile" 
ON public.user_profiles 
FOR SELECT 
TO authenticated 
USING (auth.uid() = user_id);

-- 2. Service role her şeyi yapabilir
CREATE POLICY "Service role full access" 
ON public.user_profiles 
FOR ALL 
TO service_role 
USING (true)
WITH CHECK (true);

-- 3. Authenticated users kendi profillerini oluşturabilir
CREATE POLICY "Users can create own profile" 
ON public.user_profiles 
FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid() = user_id);

-- 4. Admin kontrolü için fonksiyon kullanarak basit politika
CREATE POLICY "Function based admin access" 
ON public.user_profiles 
FOR ALL 
TO authenticated 
USING (public.get_current_user_role() IN ('admin', 'staff'))
WITH CHECK (public.get_current_user_role() IN ('admin', 'staff'));
