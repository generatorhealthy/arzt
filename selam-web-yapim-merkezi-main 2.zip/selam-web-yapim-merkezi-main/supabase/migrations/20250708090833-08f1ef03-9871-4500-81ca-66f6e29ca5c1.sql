
-- specialists tablosuna SEO meta alanlarını ekleyelim
ALTER TABLE public.specialists 
ADD COLUMN seo_title TEXT,
ADD COLUMN seo_description TEXT,
ADD COLUMN seo_keywords TEXT;
