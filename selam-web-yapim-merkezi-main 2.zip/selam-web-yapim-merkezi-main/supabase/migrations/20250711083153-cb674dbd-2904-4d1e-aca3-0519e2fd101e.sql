
-- Personel maaşları tablosunu oluştur
CREATE TABLE public.employee_salaries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_name TEXT NOT NULL,
  employee_surname TEXT NOT NULL,
  base_salary NUMERIC NOT NULL,
  bonus NUMERIC DEFAULT 0,
  deductions NUMERIC DEFAULT 0,
  total_salary NUMERIC,
  salary_month INTEGER NOT NULL,
  salary_year INTEGER NOT NULL,
  payment_date DATE,
  status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Toplam maaş hesaplama triggeri ekle
CREATE OR REPLACE FUNCTION calculate_total_salary()
RETURNS TRIGGER AS $$
BEGIN
  NEW.total_salary := NEW.base_salary + COALESCE(NEW.bonus, 0) - COALESCE(NEW.deductions, 0);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_calculate_total_salary
  BEFORE INSERT OR UPDATE ON public.employee_salaries
  FOR EACH ROW
  EXECUTE FUNCTION calculate_total_salary();

-- RLS politikalarını etkinleştir
ALTER TABLE public.employee_salaries ENABLE ROW LEVEL SECURITY;

-- Admin kullanıcıları tüm maaş kayıtlarını yönetebilir
CREATE POLICY "Admin can manage employee salaries" 
  ON public.employee_salaries 
  FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin' 
    AND is_approved = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin' 
    AND is_approved = true
  ));

-- İlk kayıtları ekle (Yağmur ve Fatma için mevcut ay)
INSERT INTO public.employee_salaries (
  employee_name, 
  employee_surname, 
  base_salary, 
  salary_month, 
  salary_year, 
  status
) VALUES 
('Yağmur', 'Kaya', 15000, EXTRACT(MONTH FROM CURRENT_DATE)::INTEGER, EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER, 'pending'),
('Fatma', 'Demir', 15000, EXTRACT(MONTH FROM CURRENT_DATE)::INTEGER, EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER, 'pending');
