
-- RLS'yi tamamen kapat
ALTER TABLE public.appointments DISABLE ROW LEVEL SECURITY;

-- Tüm mevcut politikaları sil
DROP POLICY IF EXISTS "Enable insert for everyone" ON public.appointments;
DROP POLICY IF EXISTS "Enable select for authenticated users" ON public.appointments;
DROP POLICY IF EXISTS "Admins can do everything" ON public.appointments;
DROP POLICY IF EXISTS "Specialists can manage own appointments" ON public.appointments;
DROP POLICY IF EXISTS "Allow all inserts" ON public.appointments;
DROP POLICY IF EXISTS "Anyone can create appointments" ON public.appointments;

-- RLS'yi tekrar aç
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Herkesin INSERT yapabilmesi için basit politika (anonymous kullanıcılar dahil)
CREATE POLICY "Allow anonymous inserts" ON public.appointments
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Authenticated kullanıcılar için SELECT politikası
CREATE POLICY "Allow authenticated select" ON public.appointments
  FOR SELECT
  TO authenticated
  USING (true);

-- Admin ve specialist politikaları
CREATE POLICY "Allow admin all operations" ON public.appointments
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role = 'admin'::user_role
  ));

CREATE POLICY "Allow specialist own appointments" ON public.appointments
  FOR ALL
  TO authenticated
  USING (specialist_id IN (
    SELECT specialists.id FROM specialists 
    WHERE specialists.user_id = auth.uid()
  ));

-- Politikaları kontrol et
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'appointments'
ORDER BY policyname;
