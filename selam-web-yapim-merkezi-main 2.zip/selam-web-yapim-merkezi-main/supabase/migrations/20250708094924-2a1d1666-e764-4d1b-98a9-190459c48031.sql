
-- Herkesın randevu oluşturabilmesı için yeni politika ekle
CREATE POLICY "Anyone can create appointments" 
  ON public.appointments 
  FOR INSERT 
  WITH CHECK (true);
