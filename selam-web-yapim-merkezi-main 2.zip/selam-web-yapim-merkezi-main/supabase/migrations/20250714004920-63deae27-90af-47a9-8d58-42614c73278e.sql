-- Add payment_day column to specialists table
ALTER TABLE public.specialists 
ADD COLUMN payment_day integer DEFAULT EXTRACT(DAY FROM NOW());

-- Update existing specialists with the payment days from the provided list
UPDATE public.specialists SET payment_day = 5 WHERE name = 'Nur Aslan';
UPDATE public.specialists SET payment_day = 22 WHERE name = 'Ayfer Aydın';
UPDATE public.specialists SET payment_day = 12 WHERE name LIKE '%Mürüvvet Kara%';
UPDATE public.specialists SET payment_day = 12 WHERE name LIKE '%Şule Uludağ%';
UPDATE public.specialists SET payment_day = 12 WHERE name LIKE '%Erkan Arıkan%';
UPDATE public.specialists SET payment_day = 8 WHERE name LIKE '%Nida Nur Çetin%';
UPDATE public.specialists SET payment_day = 11 WHERE name LIKE '%Şevval Gökşin Pişkin%';
UPDATE public.specialists SET payment_day = 12 WHERE name LIKE '%Hüseyin Burak Coşkun%';
UPDATE public.specialists SET payment_day = 13 WHERE name LIKE '%Deniz Özmeriç Şanal%';
UPDATE public.specialists SET payment_day = 13 WHERE name LIKE '%Yeliz Şenyuva%';
UPDATE public.specialists SET payment_day = 13 WHERE name LIKE '%Sibel Kirezci%';
UPDATE public.specialists SET payment_day = 14 WHERE name LIKE '%Şeyda Aras%';
UPDATE public.specialists SET payment_day = 14 WHERE name LIKE '%Sedanur Sürme%';
UPDATE public.specialists SET payment_day = 14 WHERE name LIKE '%Merve Küçükçelik%';
UPDATE public.specialists SET payment_day = 12 WHERE name LIKE '%Ebru Özcan%';
UPDATE public.specialists SET payment_day = 14 WHERE name LIKE '%Tahibe Derici%';
UPDATE public.specialists SET payment_day = 14 WHERE name LIKE '%Gökçe Uruk%';
UPDATE public.specialists SET payment_day = 14 WHERE name LIKE '%Su Ayhan%';
UPDATE public.specialists SET payment_day = 14 WHERE name LIKE '%Revan Kaptanoğlu%';
UPDATE public.specialists SET payment_day = 15 WHERE name LIKE '%Büşra Demir%';
UPDATE public.specialists SET payment_day = 15 WHERE name LIKE '%Zeynep Çetin%';
UPDATE public.specialists SET payment_day = 15 WHERE name LIKE '%Kadriye Erdoğan%';
UPDATE public.specialists SET payment_day = 15 WHERE name LIKE '%Yıldız Günel%';
UPDATE public.specialists SET payment_day = 17 WHERE name LIKE '%Fatma Çiftçi%';
UPDATE public.specialists SET payment_day = 18 WHERE name LIKE '%Ayşenur Vural%';
UPDATE public.specialists SET payment_day = 18 WHERE name LIKE '%Lefke Tezcan%';
UPDATE public.specialists SET payment_day = 18 WHERE name LIKE '%Özge Larçın%';
UPDATE public.specialists SET payment_day = 20 WHERE name LIKE '%Şenay Esen%';
UPDATE public.specialists SET payment_day = 21 WHERE name LIKE '%Fatma Güngören%';
UPDATE public.specialists SET payment_day = 21 WHERE name LIKE '%Nurdan Yurduseven%';
UPDATE public.specialists SET payment_day = 22 WHERE name LIKE '%Ayşe Dölek Kerbel%';