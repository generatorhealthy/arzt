
-- Update the check constraint to include the new status options
ALTER TABLE public.legal_proceedings 
DROP CONSTRAINT legal_proceedings_status_check;

ALTER TABLE public.legal_proceedings 
ADD CONSTRAINT legal_proceedings_status_check 
CHECK (status IN ('İCRA_AÇILDI', 'İTİRAZ_ETTİ', 'İTİRAZ_DAVASI_AÇILDI', 'DAVA_AÇILDI', 'HACİZ_YAPILDI', 'ÖDEME_BEKLENİYOR', 'İCRA_TAMAMLANDI'));
