
-- user_role enum'una yeni 'staff' rolünü ekle
ALTER TYPE public.user_role ADD VALUE 'staff';

-- RLS politikalarını güncelleyeceğiz, önce mevcut bazı politikaları düşürelim
DROP POLICY IF EXISTS "Admins can manage all specialists" ON public.specialists;
DROP POLICY IF EXISTS "Admins can insert specialists" ON public.specialists;

-- Yeni politikalar: Staff ve Admin'ler uzman ekleyebilir
CREATE POLICY "Admins and staff can insert specialists" 
ON public.specialists 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'staff'::user_role)
    AND user_profiles.is_approved = true
  )
);

-- Staff'ler uzmanları görüntüleyebilir ve düzenleyebilir (ama silemez)
CREATE POLICY "Admins and staff can view all specialists" 
ON public.specialists 
FOR SELECT 
USING (
  (is_active = true) OR 
  (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'staff'::user_role)
    AND user_profiles.is_approved = true
  ))
);

CREATE POLICY "Admins and staff can update specialists" 
ON public.specialists 
FOR UPDATE 
USING (
  (user_id = auth.uid()) OR 
  (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'staff'::user_role)
    AND user_profiles.is_approved = true
  ))
);

-- Sadece adminler uzman silebilir ve durumunu değiştirebilir
CREATE POLICY "Only admins can delete specialists" 
ON public.specialists 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role = 'admin'::user_role
    AND user_profiles.is_approved = true
  )
);

-- get_current_user_role fonksiyonunu güncelle
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS text
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public', 'auth'
AS $function$
BEGIN
  RETURN (
    SELECT role::text 
    FROM public.user_profiles 
    WHERE user_id = auth.uid()
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'user';
END;
$function$;
