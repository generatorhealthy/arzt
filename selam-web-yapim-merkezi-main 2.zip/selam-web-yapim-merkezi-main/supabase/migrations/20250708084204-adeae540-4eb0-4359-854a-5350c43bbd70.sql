
-- user_profiles tablosuna name ve email kolonları ekleyelim
ALTER TABLE public.user_profiles 
ADD COLUMN name TEXT,
ADD COLUMN email TEXT;

-- Mevcut handle_new_user fonksiyonunu güncelleyelim
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'auth'
AS $function$
BEGIN
  INSERT INTO public.user_profiles (user_id, role, is_approved, name, email)
  VALUES (
    NEW.id, 
    CASE 
      WHEN NEW.raw_user_meta_data->>'role' = 'specialist' THEN 'specialist'::public.user_role
      WHEN NEW.raw_user_meta_data->>'role' = 'admin' THEN 'admin'::public.user_role
      ELSE 'user'::public.user_role
    END,
    CASE 
      WHEN NEW.raw_user_meta_data->>'role' = 'specialist' THEN true
      ELSE false
    END,
    NEW.raw_user_meta_data->>'name',
    NEW.email
  );
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Hata durumunda log yazalım ama kullanıcı oluşturulabilsin
    RAISE WARNING 'User profile creation failed: %', SQLERRM;
    RETURN NEW;
END;
$function$;
