
-- success_statistics tablosuna day sütunu ekle
ALTER TABLE public.success_statistics 
ADD COLUMN day integer;

-- Mevcut kayıtlarda default olarak 1 günü ata
UPDATE public.success_statistics 
SET day = 1 
WHERE day IS NULL;

-- day sütununu not null yap
ALTER TABLE public.success_statistics 
ALTER COLUMN day SET NOT NULL;

-- day sütunu için default değer ekle
ALTER TABLE public.success_statistics 
ALTER COLUMN day SET DEFAULT 1;
