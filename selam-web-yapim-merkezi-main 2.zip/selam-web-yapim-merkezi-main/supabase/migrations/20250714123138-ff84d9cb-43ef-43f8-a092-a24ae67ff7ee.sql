
-- Fix the security issue in create_client_referral_for_new_specialist function
CREATE OR REPLACE FUNCTION public.create_client_referral_for_new_specialist()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Yeni eklenen uzman için mevcut ay ve yıl için kayıt oluştur
  INSERT INTO public.client_referrals (specialist_id, year, month)
  VALUES (
    NEW.id,
    EXTRACT(YEAR FROM NOW()),
    EXTRACT(MONTH FROM NOW())
  )
  ON CONFLICT (specialist_id, year, month) DO NOTHING;
  
  RETURN NEW;
END;
$$;
