
-- Update the check constraint to include the new status
ALTER TABLE public.legal_proceedings 
DROP CONSTRAINT legal_proceedings_status_check;

ALTER TABLE public.legal_proceedings 
ADD CONSTRAINT legal_proceedings_status_check 
CHECK (status IN ('İCRA_AÇILDI', 'İTİRAZ_ETTİ', 'DAVA_AÇILDI', 'İCRA_TAMAMLANDI'));
