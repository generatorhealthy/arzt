
-- Mevcut kullanıcıyı admin yap
UPDATE public.user_profiles 
SET role = 'admin'::user_role, is_approved = true 
WHERE user_id = 'cbfd1d7f-c44d-43c0-bf00-fde6de3c9d54';

-- Admin kullanıcılarının tüm user_profiles tablosunu yönetebilmesi için ek politikalar
CREATE POLICY IF NOT EXISTS "Admins can insert user profiles" 
ON public.user_profiles 
FOR INSERT 
TO authenticated 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles existing_profile
    WHERE existing_profile.user_id = auth.uid() 
    AND existing_profile.role = 'admin'
    AND existing_profile.is_approved = true
  )
);

-- Admin kullanıcılarının randevu tablosunu tamamen yönetebilmesi
DROP POLICY IF EXISTS "Admins can manage all appointments" ON public.appointments;

CREATE POLICY "Admins can manage all appointments" 
ON public.appointments 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
);

-- Admin kullanıcılarının blog yazılarını tamamen yönetebilmesi
DROP POLICY IF EXISTS "Admins can manage all blog posts" ON public.blog_posts;

CREATE POLICY "Admins can manage all blog posts" 
ON public.blog_posts 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
);

-- Admin kullanıcılarının blog kategorilerini yönetebilmesi
CREATE POLICY "Admins can manage blog categories" 
ON public.blog_categories 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
);

-- Admin kullanıcılarının blog post kategorilerini yönetebilmesi
CREATE POLICY "Admins can manage blog post categories" 
ON public.blog_post_categories 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
);
