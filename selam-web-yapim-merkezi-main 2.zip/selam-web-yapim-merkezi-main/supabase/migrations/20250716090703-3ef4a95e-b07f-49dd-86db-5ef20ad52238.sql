
-- Tests tablosuna specialty_area sütunu ekle
ALTER TABLE tests ADD COLUMN specialty_area text;

-- Mevcut testleri psikolog ve psikolojik danışman için ayarla
UPDATE tests SET specialty_area = 'Psikolog' WHERE specialty_area IS NULL;

-- Test sonuçlarını da specialty_area'ya göre filtreleyebilmek için
-- test_results tablosuna specialty_area bilgisi ekle (opsiyonel)
ALTER TABLE test_results ADD COLUMN specialty_area text;

-- Mevcut test sonuçlarını güncelle
UPDATE test_results 
SET specialty_area = (
  SELECT specialty_area 
  FROM tests 
  WHERE tests.id = test_results.test_id
);
