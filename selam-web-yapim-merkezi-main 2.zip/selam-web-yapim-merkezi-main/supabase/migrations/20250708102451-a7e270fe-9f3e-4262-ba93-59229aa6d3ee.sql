
-- RLS'yi tamamen kapat ve sıfırdan başla
ALTER TABLE public.appointments DISABLE ROW LEVEL SECURITY;

-- Tüm mevcut politikaları temizle
DO $$ 
DECLARE
    r RECORD;
BEGIN
    FOR r IN (SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'appointments') LOOP
        EXECUTE 'DROP POLICY IF EXISTS "' || r.policyname || '" ON public.appointments';
    END LOOP;
END $$;

-- RLS'yi tekrar aktif et
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Tek bir basit politika - herkes INSERT yapabilir
CREATE POLICY "allow_all_inserts" ON public.appointments
    FOR INSERT 
    TO anon, authenticated
    WITH CHECK (true);

-- Authenticated kullanıcılar için SELECT
CREATE POLICY "allow_authenticated_select" ON public.appointments
    FOR SELECT 
    TO authenticated
    USING (true);

-- Admin politikası
CREATE POLICY "allow_admin_all" ON public.appointments
    FOR ALL 
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM user_profiles 
            WHERE user_profiles.user_id = auth.uid() 
            AND user_profiles.role = 'admin'::user_role
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM user_profiles 
            WHERE user_profiles.user_id = auth.uid() 
            AND user_profiles.role = 'admin'::user_role
        )
    );

-- Specialist politikası
CREATE POLICY "allow_specialist_own" ON public.appointments
    FOR ALL 
    TO authenticated
    USING (
        specialist_id IN (
            SELECT id FROM specialists 
            WHERE user_id = auth.uid()
        )
    )
    WITH CHECK (
        specialist_id IN (
            SELECT id FROM specialists 
            WHERE user_id = auth.uid()
        )
    );

-- Kontrol et
SELECT 
    schemaname, 
    tablename, 
    policyname, 
    cmd, 
    roles,
    qual,
    with_check
FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'appointments'
ORDER BY policyname;
