
-- Fix the security issue in add_specialist_to_customers function
CREATE OR REPLACE FUNCTION public.add_specialist_to_customers()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Yeni eklenen uzmanı müşteri yönetimine ekle
  INSERT INTO public.automatic_orders (
    customer_name,
    customer_email,
    customer_phone,
    package_name,
    package_type,
    amount,
    payment_method,
    customer_type,
    registration_date,
    monthly_payment_day,
    total_months,
    paid_months,
    is_active
  ) VALUES (
    NEW.name,
    COALESCE(NEW.email, NEW.name || '@example.com'),
    COALESCE(NEW.phone, '0 216 706 06 11'),
    NEW.specialty || ' Paketi',
    LOWER(REPLACE(NEW.specialty, ' ', '_')),
    3000, -- Varsayılan fiyat, sonradan manuel olarak güncellenecek
    'banka_havalesi',
    'individual',
    NOW(),
    1,
    24,
    ARRAY[]::integer[], -- Başlangıçta hiç ödeme yok, sonradan manuel olarak güncellenecek
    true
  )
  ON CONFLICT (customer_email) DO NOTHING;
  
  RETURN NEW;
END;
$$;
