
-- legal_proceedings tablosuna notes alanı ekle
ALTER TABLE public.legal_proceedings 
ADD COLUMN IF NOT EXISTS notes TEXT;
