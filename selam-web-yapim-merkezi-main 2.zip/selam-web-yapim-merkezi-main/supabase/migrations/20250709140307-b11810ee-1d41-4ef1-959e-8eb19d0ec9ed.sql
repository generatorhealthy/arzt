
-- Orders tablosundan tüm mevcut politikaları silelim
DROP POLICY IF EXISTS "Anyone can create orders" ON public.orders;
DROP POLICY IF EXISTS "Admins can manage all orders" ON public.orders;

-- RLS'yi tamamen kapatıp tekrar açalım
ALTER TABLE public.orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Tamamen açık bir INSERT politikası oluşturalım
CREATE POLICY "Public insert policy" 
  ON public.orders 
  FOR INSERT 
  TO public
  WITH CHECK (true);

-- Herkesin orders tablosunu okuyabilmesi için SELECT politikası
CREATE POLICY "Public select policy" 
  ON public.orders 
  FOR SELECT 
  TO public
  USING (true);

-- Admin kullanıcıları için UPDATE ve DELETE politikaları
CREATE POLICY "Admin update policy" 
  ON public.orders 
  FOR UPDATE 
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.user_profiles 
      WHERE user_id = auth.uid() 
      AND role = 'admin'::user_role
      AND is_approved = true
    )
  );

CREATE POLICY "Admin delete policy" 
  ON public.orders 
  FOR DELETE 
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.user_profiles 
      WHERE user_id = auth.uid() 
      AND role = 'admin'::user_role
      AND is_approved = true
    )
  );

-- Gerekli izinleri verelim
GRANT ALL ON public.orders TO anon;
GRANT ALL ON public.orders TO authenticated;
GRANT ALL ON public.orders TO public;
