
-- Uzmanlar tablosunu güncelle
ALTER TABLE public.specialists 
ADD COLUMN IF NOT EXISTS email TEXT,
ADD COLUMN IF NOT EXISTS phone TEXT,
ADD COLUMN IF NOT EXISTS bio TEXT,
ADD COLUMN IF NOT EXISTS education TEXT,
ADD COLUMN IF NOT EXISTS university TEXT,
ADD COLUMN IF NOT EXISTS address TEXT,
ADD COLUMN IF NOT EXISTS available_days TEXT[],
ADD COLUMN IF NOT EXISTS working_hours_start TIME,
ADD COLUMN IF NOT EXISTS working_hours_end TIME,
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id);

-- Specialists tablosu için RLS etkinleştir
ALTER TABLE public.specialists ENABLE ROW LEVEL SECURITY;

-- Herkes aktif uzmanları görebilir
CREATE POLICY "Anyone can view active specialists" 
ON public.specialists 
FOR SELECT 
USING (is_active = true);

-- Adminler tüm uzmanları yönetebilir
CREATE POLICY "Admins can manage all specialists" 
ON public.specialists 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);

-- Uzmanlar kendi profillerini düzenleyebilir
CREATE POLICY "Specialists can update their own profile" 
ON public.specialists 
FOR UPDATE 
TO authenticated 
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Uzmanlar kendi profillerini görebilir
CREATE POLICY "Specialists can view their own profile" 
ON public.specialists 
FOR SELECT 
TO authenticated 
USING (user_id = auth.uid() OR is_active = true);

-- Randevular için tablo oluştur
CREATE TABLE IF NOT EXISTS public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  specialist_id UUID REFERENCES public.specialists(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  patient_email TEXT NOT NULL,
  patient_phone TEXT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  appointment_type TEXT NOT NULL CHECK (appointment_type IN ('online', 'yüzyüze')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Appointments tablosu için RLS
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Adminler tüm randevuları görebilir
CREATE POLICY "Admins can manage all appointments" 
ON public.appointments 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);

-- Uzmanlar kendi randevularını görebilir ve yönetebilir
CREATE POLICY "Specialists can manage their own appointments" 
ON public.appointments 
FOR ALL 
TO authenticated 
USING (
  specialist_id IN (
    SELECT id FROM public.specialists 
    WHERE user_id = auth.uid()
  )
);
