
-- First, let's check what policies exist and then update them to be more permissive for order creation
-- Remove the existing restrictive policy
DROP POLICY IF EXISTS "Enable insert for all users" ON public.orders;

-- Create a completely permissive policy for inserting orders
CREATE POLICY "Allow all order insertions" 
  ON public.orders 
  FOR INSERT 
  WITH CHECK (true);

-- Ensure proper grants are in place
GRANT INSERT ON public.orders TO service_role;
GRANT INSERT ON public.orders TO anon;
GRANT INSERT ON public.orders TO authenticated;

-- Also ensure the service role can bypass RLS entirely for this table
ALTER TABLE public.orders FORCE ROW LEVEL SECURITY;
