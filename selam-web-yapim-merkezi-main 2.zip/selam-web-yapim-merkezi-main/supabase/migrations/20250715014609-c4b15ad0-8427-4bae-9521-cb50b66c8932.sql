
-- Tests tablosu zaten mevcut, test_results tablosu oluşturalım
CREATE TABLE IF NOT EXISTS public.test_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  test_id UUID REFERENCES public.tests(id) NOT NULL,
  specialist_id UUID REFERENCES public.specialists(id) NOT NULL,
  patient_name TEXT NOT NULL,
  patient_email TEXT NOT NULL,
  answers JSONB NOT NULL DEFAULT '{}',
  results JSONB NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'completed',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Test questions tablosu oluşturalım
CREATE TABLE IF NOT EXISTS public.test_questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  test_id UUID REFERENCES public.tests(id) NOT NULL,
  question_text TEXT NOT NULL,
  question_type TEXT NOT NULL DEFAULT 'multiple_choice', -- multiple_choice, text, scale
  options JSONB DEFAULT '[]',
  step_number INTEGER NOT NULL DEFAULT 1,
  is_required BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- RLS politikaları
ALTER TABLE public.test_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_questions ENABLE ROW LEVEL SECURITY;

-- Test results için politikalar
CREATE POLICY "Specialists can view their own test results" 
ON public.test_results 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.specialists s 
  WHERE s.id = test_results.specialist_id AND s.user_id = auth.uid()
));

CREATE POLICY "Admin and staff can view all test results" 
ON public.test_results 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.user_profiles 
  WHERE user_id = auth.uid() 
  AND role = ANY(ARRAY['admin'::user_role, 'staff'::user_role]) 
  AND is_approved = true
));

CREATE POLICY "Anyone can insert test results" 
ON public.test_results 
FOR INSERT 
WITH CHECK (true);

-- Test questions için politikalar
CREATE POLICY "Anyone can view test questions" 
ON public.test_questions 
FOR SELECT 
USING (true);

CREATE POLICY "Admin and staff can manage test questions" 
ON public.test_questions 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.user_profiles 
  WHERE user_id = auth.uid() 
  AND role = ANY(ARRAY['admin'::user_role, 'staff'::user_role]) 
  AND is_approved = true
))
WITH CHECK (EXISTS (
  SELECT 1 FROM public.user_profiles 
  WHERE user_id = auth.uid() 
  AND role = ANY(ARRAY['admin'::user_role, 'staff'::user_role]) 
  AND is_approved = true
));

-- Trigger fonksiyonu güncellenmiş zaman için
CREATE OR REPLACE FUNCTION update_test_results_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE OR REPLACE FUNCTION update_test_questions_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger'ları oluştur
CREATE TRIGGER test_results_updated_at 
BEFORE UPDATE ON public.test_results 
FOR EACH ROW EXECUTE PROCEDURE update_test_results_updated_at();

CREATE TRIGGER test_questions_updated_at 
BEFORE UPDATE ON public.test_questions 
FOR EACH ROW EXECUTE PROCEDURE update_test_questions_updated_at();
