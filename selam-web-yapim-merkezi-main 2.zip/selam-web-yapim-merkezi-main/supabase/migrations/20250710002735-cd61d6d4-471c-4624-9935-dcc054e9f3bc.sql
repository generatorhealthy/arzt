
-- user_role enum'una 'staff' değerini ekle (eğer yoksa)
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'staff' AND enumtypid = 'public.user_role'::regtype) THEN
        ALTER TYPE public.user_role ADD VALUE 'staff';
    END IF;
END $$;

-- Mevcut staff kullanıcılarının rollerini kontrol et ve düzelt
UPDATE public.user_profiles 
SET role = 'staff'::user_role 
WHERE email = 'test@doktorumol.com.tr' 
  AND role != 'staff'::user_role;

-- Staff kullanıcılarının panele erişim politikalarını güncelle
DROP POLICY IF EXISTS "Admins and staff can view all specialists" ON public.specialists;
DROP POLICY IF EXISTS "Admins and staff can insert specialists" ON public.specialists;
DROP POLICY IF EXISTS "Admins and staff can update specialists" ON public.specialists;

-- Yeni politikalar: Staff ve Admin'ler uzman yönetimi yapabilir
CREATE POLICY "Admins and staff can view all specialists" 
ON public.specialists 
FOR SELECT 
USING (
  (is_active = true) OR 
  (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'staff'::user_role)
    AND user_profiles.is_approved = true
  ))
);

CREATE POLICY "Admins and staff can insert specialists" 
ON public.specialists 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'staff'::user_role)
    AND user_profiles.is_approved = true
  )
);

CREATE POLICY "Admins and staff can update specialists" 
ON public.specialists 
FOR UPDATE 
USING (
  (user_id = auth.uid()) OR 
  (EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role IN ('admin'::user_role, 'staff'::user_role)
    AND user_profiles.is_approved = true
  ))
);

-- Sadece adminler uzman silebilir
CREATE POLICY "Only admins can delete specialists" 
ON public.specialists 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE user_profiles.user_id = auth.uid() 
    AND user_profiles.role = 'admin'::user_role
    AND user_profiles.is_approved = true
  )
);
