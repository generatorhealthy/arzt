
-- get_current_user_role fonksiyonunun search path'ini güvenli hale getirelim
ALTER FUNCTION public.get_current_user_role()
SET search_path = '';
