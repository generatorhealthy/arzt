
-- Fatima Doktorum Ol ve Zeynep Yağmur Çingen kullanıcılarını staff olarak ayarla
UPDATE public.user_profiles 
SET role = 'staff'::user_role 
WHERE email IN ('test@doktorumol.com.tr', 'randevu@doktorumol.com.tr')
  AND role != 'staff'::user_role;

-- Ayrıca bu kullanıcıların onaylandığından emin olalım
UPDATE public.user_profiles 
SET is_approved = true
WHERE email IN ('test@doktorumol.com.tr', 'randevu@doktorumol.com.tr')
  AND is_approved != true;
