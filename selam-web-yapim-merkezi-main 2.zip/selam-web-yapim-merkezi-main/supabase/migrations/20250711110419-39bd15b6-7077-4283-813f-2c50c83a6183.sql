
-- Danışan yönlendirme tablosu oluştur
CREATE TABLE public.client_referrals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  specialist_id UUID NOT NULL REFERENCES public.specialists(id) ON DELETE CASCADE,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL,
  is_referred BOOLEAN NOT NULL DEFAULT false,
  referred_at TIMESTAMP WITH TIME ZONE,
  referred_by UUID REFERENCES auth.users(id),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(specialist_id, year, month)
);

-- RLS politikaları ekle
ALTER TABLE public.client_referrals ENABLE ROW LEVEL SECURITY;

-- Admin ve staff yetkileri
CREATE POLICY "Admins can manage client referrals" 
ON public.client_referrals 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
    AND is_approved = true
  )
);

CREATE POLICY "Staff can manage client referrals" 
ON public.client_referrals 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'staff'
    AND is_approved = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'staff'
    AND is_approved = true
  )
);

-- Yeni uzman eklendiğinde otomatik olarak mevcut ay için kayıt oluştur
CREATE OR REPLACE FUNCTION public.create_client_referral_for_new_specialist()
RETURNS TRIGGER AS $$
BEGIN
  -- Yeni eklenen uzman için mevcut ay ve yıl için kayıt oluştur
  INSERT INTO public.client_referrals (specialist_id, year, month)
  VALUES (
    NEW.id,
    EXTRACT(YEAR FROM NOW()),
    EXTRACT(MONTH FROM NOW())
  )
  ON CONFLICT (specialist_id, year, month) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger oluştur
CREATE TRIGGER trigger_create_client_referral_for_new_specialist
  AFTER INSERT ON public.specialists
  FOR EACH ROW
  EXECUTE FUNCTION public.create_client_referral_for_new_specialist();

-- Mevcut uzmanlar için geçerli ay kayıtlarını oluştur
INSERT INTO public.client_referrals (specialist_id, year, month)
SELECT 
  id,
  EXTRACT(YEAR FROM NOW()),
  EXTRACT(MONTH FROM NOW())
FROM public.specialists
WHERE is_active = true
ON CONFLICT (specialist_id, year, month) DO NOTHING;
