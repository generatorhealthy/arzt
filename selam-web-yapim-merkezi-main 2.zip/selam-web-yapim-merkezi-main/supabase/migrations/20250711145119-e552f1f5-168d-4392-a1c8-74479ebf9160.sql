
-- Önce mevcut uzmanları kontrol edelim ve müşteri yönetimine ekleyelim
-- Ayfer Aydın ve Nur Aslan zaten ekli olduğu için onları hariç tutalım

INSERT INTO public.automatic_orders (
  customer_name,
  customer_email,
  customer_phone,
  package_name,
  package_type,
  amount,
  payment_method,
  customer_type,
  registration_date,
  monthly_payment_day,
  total_months,
  paid_months,
  is_active
)
SELECT 
  s.name,
  COALESCE(s.email, s.name || '@example.com'),
  COALESCE(s.phone, '0 216 706 06 11'),
  s.specialty || ' Paketi',
  LOWER(REPLACE(s.specialty, ' ', '_')),
  CASE 
    WHEN s.name = 'Psk. Şevval Gökşin Pişkin' THEN 3600
    ELSE 3000
  END,
  'banka_havalesi',
  'individual',
  CASE 
    WHEN s.name = 'Psk. Şevval Gökşin Pişkin' THEN NOW() - INTERVAL '5 months'
    WHEN s.name = 'Psk. Nida Nur Çetin' THEN NOW() - INTERVAL '4 months'
    WHEN s.name = 'Psk. Dan. Mürüvvet Kara' THEN NOW() - INTERVAL '15 months'
    WHEN s.name = 'Psk. Hüseyin Burak Coşkun' THEN NOW() - INTERVAL '5 months'
    WHEN s.name = 'Uzm. Bağımlılık Danışmanı Erkan Arıkan' THEN NOW() - INTERVAL '1 month'
    WHEN s.name = 'Uzm. Aile Danışmanı Şule Uludağ' THEN NOW() - INTERVAL '1 month'
    ELSE NOW()
  END,
  1,
  24,
  CASE 
    WHEN s.name = 'Psk. Şevval Gökşin Pişkin' THEN ARRAY[1,2,3,4,5]
    WHEN s.name = 'Psk. Nida Nur Çetin' THEN ARRAY[1,2,3,4]
    WHEN s.name = 'Psk. Dan. Mürüvvet Kara' THEN ARRAY[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    WHEN s.name = 'Psk. Hüseyin Burak Coşkun' THEN ARRAY[1,2,3,4,5]
    WHEN s.name = 'Uzm. Bağımlılık Danışmanı Erkan Arıkan' THEN ARRAY[1]
    WHEN s.name = 'Uzm. Aile Danışmanı Şule Uludağ' THEN ARRAY[1]
    ELSE ARRAY[]::integer[]
  END,
  true
FROM public.specialists s
WHERE s.name NOT IN ('Ayfer Aydın', 'Nur Aslan')
  AND NOT EXISTS (
    SELECT 1 FROM public.automatic_orders ao 
    WHERE ao.customer_email = COALESCE(s.email, s.name || '@example.com')
  );

-- Otomatik ekleme sistemi için trigger fonksiyonu oluştur
CREATE OR REPLACE FUNCTION public.add_specialist_to_customers()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- Yeni eklenen uzmanı müşteri yönetimine ekle
  INSERT INTO public.automatic_orders (
    customer_name,
    customer_email,
    customer_phone,
    package_name,
    package_type,
    amount,
    payment_method,
    customer_type,
    registration_date,
    monthly_payment_day,
    total_months,
    paid_months,
    is_active
  ) VALUES (
    NEW.name,
    COALESCE(NEW.email, NEW.name || '@example.com'),
    COALESCE(NEW.phone, '0 216 706 06 11'),
    NEW.specialty || ' Paketi',
    LOWER(REPLACE(NEW.specialty, ' ', '_')),
    3000, -- Varsayılan fiyat, sonradan manuel olarak güncellenecek
    'banka_havalesi',
    'individual',
    NOW(),
    1,
    24,
    ARRAY[]::integer[], -- Başlangıçta hiç ödeme yok, sonradan manuel olarak güncellenecek
    true
  )
  ON CONFLICT (customer_email) DO NOTHING;
  
  RETURN NEW;
END;
$$;

-- Mevcut trigger'ı sil ve yenisini oluştur
DROP TRIGGER IF EXISTS trigger_add_specialist_to_customers ON public.specialists;
CREATE TRIGGER trigger_add_specialist_to_customers
  AFTER INSERT ON public.specialists
  FOR EACH ROW
  EXECUTE FUNCTION public.add_specialist_to_customers();
