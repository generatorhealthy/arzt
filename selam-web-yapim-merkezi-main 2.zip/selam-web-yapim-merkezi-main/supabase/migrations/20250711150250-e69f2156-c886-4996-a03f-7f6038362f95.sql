
-- automatic_orders tablosuna admin ve staff kullanıcılarının insert yapabilmesi için politika ekle
DROP POLICY IF EXISTS "Admin can manage automatic orders" ON public.automatic_orders;
DROP POLICY IF EXISTS "Public can view automatic orders" ON public.automatic_orders;

-- Admin ve Staff kullanıcıları için tam yetki politikası
CREATE POLICY "Admin and Staff can manage automatic orders" 
  ON public.automatic_orders 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role IN ('admin', 'staff')
      AND user_profiles.is_approved = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE user_profiles.user_id = auth.uid() 
      AND user_profiles.role IN ('admin', 'staff') 
      AND user_profiles.is_approved = true
    )
  );

-- Herkesin automatic_orders tablosunu görüntüleyebilmesi için politika
CREATE POLICY "Public can view automatic orders" 
  ON public.automatic_orders 
  FOR SELECT 
  USING (true);

-- Trigger fonksiyonunun çalışabilmesi için service role'e tam yetki ver
GRANT ALL ON public.automatic_orders TO service_role;
