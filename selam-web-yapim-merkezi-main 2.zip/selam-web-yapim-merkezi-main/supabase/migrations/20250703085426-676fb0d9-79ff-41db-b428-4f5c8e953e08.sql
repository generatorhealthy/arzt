
-- Adminlerin uzman ekleyebilmesi için INSERT policy'si ekle
CREATE POLICY "Admins can insert specialists" 
ON public.specialists 
FOR INSERT 
TO authenticated 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);
