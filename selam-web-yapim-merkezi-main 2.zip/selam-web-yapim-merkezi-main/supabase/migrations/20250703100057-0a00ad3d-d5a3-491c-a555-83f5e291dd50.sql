
-- Önce mevcut problematik policy'leri kaldıralım
DROP POLICY IF EXISTS "Users can view their own profile or admins can view all" ON public.user_profiles;
DROP POLICY IF EXISTS "Admins can insert user profiles" ON public.user_profiles;

-- Güvenli bir function oluşturalım
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT AS $$
BEGIN
  RETURN (
    SELECT role::text 
    FROM public.user_profiles 
    WHERE user_id = auth.uid()
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'user';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Yeni güvenli policy'leri oluşturalım
CREATE POLICY "Users can view their own profile" 
ON public.user_profiles 
FOR SELECT 
TO authenticated 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all profiles" 
ON public.user_profiles 
FOR SELECT 
TO authenticated 
USING (public.get_current_user_role() = 'admin');

CREATE POLICY "Service role can insert profiles" 
ON public.user_profiles 
FOR INSERT 
TO service_role 
WITH CHECK (true);

CREATE POLICY "Authenticated users can insert their own profile" 
ON public.user_profiles 
FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid() = user_id);

-- Ali kullanıcısı için admin profili oluşturalım
-- Önce kullanıcının ID'sini bulalım ve admin profili ekleyelim
DO $$
DECLARE
    user_uuid UUID;
BEGIN
    -- ali@ali.com kullanıcısının ID'sini bulalım
    SELECT id INTO user_uuid 
    FROM auth.users 
    WHERE email = 'ali@ali.com';
    
    IF user_uuid IS NOT NULL THEN
        -- Eğer profil yoksa oluşturalım
        INSERT INTO public.user_profiles (user_id, role, is_approved)
        VALUES (user_uuid, 'admin'::user_role, true)
        ON CONFLICT (user_id) DO UPDATE SET 
            role = 'admin'::user_role,
            is_approved = true;
            
        RAISE NOTICE 'Admin profili oluşturuldu/güncellendi: %', user_uuid;
    ELSE
        RAISE NOTICE 'ali@ali.com kullanıcısı bulunamadı';
    END IF;
END $$;
