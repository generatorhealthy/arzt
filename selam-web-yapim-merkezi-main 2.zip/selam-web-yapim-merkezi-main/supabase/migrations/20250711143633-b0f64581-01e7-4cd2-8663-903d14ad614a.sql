
-- Mevcut uzmanları müşteri yönetimine ekle (zaten ekli olanları hariç)
INSERT INTO public.automatic_orders (
  customer_name,
  customer_email,
  customer_phone,
  package_name,
  package_type,
  amount,
  payment_method,
  customer_type,
  registration_date,
  monthly_payment_day,
  total_months,
  paid_months,
  is_active
) VALUES
-- Psk. Şevval Gökşin Pişkin
(
  'Psk. Şevval Gökşin Pişkin',
  'sevval.pishkin@example.com',
  '0 216 706 06 11',
  'Psikolog Paketi',
  'psikolog',
  3600,
  'banka_havalesi',
  'individual',
  NOW() - INTERVAL '5 months',
  1,
  24,
  ARRAY[1,2,3,4,5],
  true
),
-- Psk. Nida Nur Çetin
(
  'Psk. Nida Nur Çetin',
  'nida.cetin@example.com',
  '0 216 706 06 11',
  'Psikolog Paketi',
  'psikolog',
  3000,
  'banka_havalesi',
  'individual',
  NOW() - INTERVAL '4 months',
  1,
  24,
  ARRAY[1,2,3,4],
  true
),
-- Psk. Dan. Mürüvvet Kara
(
  'Psk. Dan. Mürüvvet Kara',
  'muruvvet.kara@example.com',
  '0 216 706 06 11',
  'Psikolog Danışman Paketi',
  'psikolog',
  3000,
  'banka_havalesi',
  'individual',
  NOW() - INTERVAL '15 months',
  1,
  24,
  ARRAY[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15],
  true
),
-- Psk. Hüseyin Burak Coşkun
(
  'Psk. Hüseyin Burak Coşkun',
  'burak.coskun@example.com',
  '0 216 706 06 11',
  'Psikolog Paketi',
  'psikolog',
  3000,
  'banka_havalesi',
  'individual',
  NOW() - INTERVAL '5 months',
  1,
  24,
  ARRAY[1,2,3,4,5],
  true
),
-- Uzm. Bağımlılık Danışmanı Erkan Arıkan
(
  'Uzm. Bağımlılık Danışmanı Erkan Arıkan',
  'erkan.arikan@example.com',
  '0 216 706 06 11',
  'Bağımlılık Danışmanı Paketi',
  'bagimlilik_danismani',
  3000,
  'banka_havalesi',
  'individual',
  NOW() - INTERVAL '1 month',
  1,
  24,
  ARRAY[1],
  true
),
-- Uzm. Aile Danışmanı Şule Uludağ
(
  'Uzm. Aile Danışmanı Şule Uludağ',
  'sule.uludag@example.com',
  '0 216 706 06 11',
  'Aile Danışmanı Paketi',
  'aile_danismani',
  3000,
  'banka_havalesi',
  'individual',
  NOW() - INTERVAL '1 month',
  1,
  24,
  ARRAY[1],
  true
)
ON CONFLICT (customer_email) DO NOTHING;

-- Yeni uzmanlar eklendiğinde otomatik olarak müşteri yönetimine eklemek için trigger fonksiyonu
CREATE OR REPLACE FUNCTION public.add_specialist_to_customers()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- Yeni eklenen uzmanı müşteri yönetimine ekle
  INSERT INTO public.automatic_orders (
    customer_name,
    customer_email,
    customer_phone,
    package_name,
    package_type,
    amount,
    payment_method,
    customer_type,
    registration_date,
    monthly_payment_day,
    total_months,
    paid_months,
    is_active
  ) VALUES (
    NEW.name,
    COALESCE(NEW.email, NEW.name || '@example.com'),
    COALESCE(NEW.phone, '0 216 706 06 11'),
    NEW.specialty || ' Paketi',
    LOWER(REPLACE(NEW.specialty, ' ', '_')),
    3000, -- Varsayılan fiyat, sonradan manuel olarak güncellenecek
    'banka_havalesi',
    'individual',
    NOW(),
    1,
    24,
    ARRAY[]::integer[], -- Başlangıçta hiç ödeme yok, sonradan manuel olarak güncellenecek
    true
  )
  ON CONFLICT (customer_email) DO NOTHING;
  
  RETURN NEW;
END;
$$;

-- Trigger'ı specialists tablosuna ekle
DROP TRIGGER IF EXISTS trigger_add_specialist_to_customers ON public.specialists;
CREATE TRIGGER trigger_add_specialist_to_customers
  AFTER INSERT ON public.specialists
  FOR EACH ROW
  EXECUTE FUNCTION public.add_specialist_to_customers();
