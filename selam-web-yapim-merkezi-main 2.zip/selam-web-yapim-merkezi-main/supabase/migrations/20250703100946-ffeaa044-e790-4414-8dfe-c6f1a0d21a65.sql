
-- Admin kullanıcıların user_profiles tablosunu güncelleyebilmesi için policy ekle
CREATE POLICY "Admins can update all profiles" 
ON public.user_profiles 
FOR UPDATE 
USING (get_current_user_role() = 'admin')
WITH CHECK (get_current_user_role() = 'admin');

-- Admin kullanıcıların user_profiles tablosundan kayıt silebilmesi için policy ekle
CREATE POLICY "Admins can delete all profiles" 
ON public.user_profiles 
FOR DELETE 
USING (get_current_user_role() = 'admin');
