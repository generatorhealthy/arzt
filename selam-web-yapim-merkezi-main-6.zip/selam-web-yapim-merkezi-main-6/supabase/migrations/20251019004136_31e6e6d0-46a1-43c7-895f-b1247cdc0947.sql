-- Bugün için siparişleri oluştur
SELECT generate_monthly_orders();